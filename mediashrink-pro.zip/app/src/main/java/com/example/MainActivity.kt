package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.model.ToolType
import com.example.ui.screens.*
import com.example.ui.theme.MediaSlimTheme
import com.example.viewmodel.MediaSlimViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MediaSlimTheme {
                val navController = rememberNavController()
                val sharedViewModel: MediaSlimViewModel = viewModel()

                NavHost(
                    navController = navController,
                    startDestination = "home"
                ) {
                    composable("home") {
                        HomeScreen(
                            viewModel = sharedViewModel,
                            onNavigateToTool = { tool ->
                                navController.navigate(tool.route)
                            },
                            onNavigateToHistory = {
                                navController.navigate("history")
                            }
                        )
                    }

                    composable("history") {
                        HistoryScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    // --- Compression Tools ---
                    composable(ToolType.IMAGE_COMPRESS.route) {
                        ImageCompressScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.VIDEO_COMPRESS.route) {
                        VideoCompressScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.AUDIO_COMPRESS.route) {
                        AudioCompressScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.GIF_COMPRESS.route) {
                        GifCompressScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    // --- Video Tools ---
                    composable(ToolType.VIDEO_TO_GIF.route) {
                        VideoToGifScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.VIDEO_CODEC_CHANGER.route) {
                        VideoCodecChangerScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.VIDEO_TRIM.route) {
                        VideoTrimScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.VIDEO_SPLIT.route) {
                        VideoSplitScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    // --- Audio Tools ---
                    composable(ToolType.AUDIO_FORMAT_CHANGER.route) {
                        AudioFormatChangerScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.AUDIO_EXTRACT.route) {
                        AudioExtractScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    // --- AI Photo Suite ---
                    composable(ToolType.BG_REMOVER.route) {
                        BgRemoverScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.OBJECT_ERASER.route) {
                        ObjectEraserScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.ICON_EXTRACTOR.route) {
                        IconExtractorScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    // --- Documents & New Pro Tools ---
                    composable(ToolType.PDF_MASTER.route) {
                        PdfMasterScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.AUDIO_DENOISER.route) {
                        AudioDenoiserScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }

                    composable(ToolType.SUBTITLE_INJECTOR.route) {
                        SubtitleInjectorScreen(
                            viewModel = sharedViewModel,
                            onNavigateBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
