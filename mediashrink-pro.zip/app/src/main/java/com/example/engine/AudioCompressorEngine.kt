package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

object AudioCompressorEngine {

    suspend fun compressAudio(
        context: Context,
        inputUri: Uri,
        targetBitrateKbps: Int = 128,
        targetSampleRate: Int = 44100,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, inputUri, "audio_comp_in", ".audio")
        val outputFile = StorageUtils.getOutputCacheFile(context, "compressed_audio", "m4a")

        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(tempInput.absolutePath)

            var audioTrackIndex = -1
            var inputFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    inputFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || inputFormat == null) {
                throw IllegalStateException("No audio track found in file")
            }

            extractor.selectTrack(audioTrackIndex)

            val inputMime = inputFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mp4a-latm"
            val channelCount = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            } else 2

            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            } else targetSampleRate

            val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) {
                inputFormat.getLong(MediaFormat.KEY_DURATION)
            } else 1L

            // 1. Decoder
            val decoder = MediaCodec.createDecoderByType(inputMime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            // 2. Encoder (AAC)
            val encoderFormat = MediaFormat.createAudioFormat(
                MediaFormat.MIMETYPE_AUDIO_AAC,
                sampleRate,
                channelCount
            ).apply {
                setInteger(MediaFormat.KEY_BIT_RATE, targetBitrateKbps * 1000)
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
            }

            val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(encoderFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var muxerTrackIndex = -1
            var muxerStarted = false

            val decoderBufferInfo = MediaCodec.BufferInfo()
            val encoderBufferInfo = MediaCodec.BufferInfo()

            var sawInputEOS = false
            var sawDecoderOutputEOS = false
            var sawEncoderOutputEOS = false

            val TIMEOUT_US = 5000L

            while (!sawEncoderOutputEOS) {
                // Supply input to decoder
                if (!sawInputEOS) {
                    val inIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                    if (inIndex >= 0) {
                        val inBuffer = decoder.getInputBuffer(inIndex)
                        if (inBuffer != null) {
                            val sampleSize = extractor.readSampleData(inBuffer, 0)
                            if (sampleSize < 0) {
                                sawInputEOS = true
                                decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            } else {
                                val sampleTime = extractor.sampleTime
                                decoder.queueInputBuffer(inIndex, 0, sampleSize, sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                // Drain decoder into encoder
                if (!sawDecoderOutputEOS) {
                    val decOutIndex = decoder.dequeueOutputBuffer(decoderBufferInfo, TIMEOUT_US)
                    if (decOutIndex >= 0) {
                        val decBuffer = decoder.getOutputBuffer(decOutIndex)
                        if (decBuffer != null && decoderBufferInfo.size > 0) {
                            val encInIndex = encoder.dequeueInputBuffer(TIMEOUT_US)
                            if (encInIndex >= 0) {
                                val encInBuffer = encoder.getInputBuffer(encInIndex)
                                if (encInBuffer != null) {
                                    encInBuffer.clear()
                                    encInBuffer.put(decBuffer)
                                    val flags = if ((decoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                        sawDecoderOutputEOS = true
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                    } else 0

                                    encoder.queueInputBuffer(
                                        encInIndex,
                                        0,
                                        decoderBufferInfo.size,
                                        decoderBufferInfo.presentationTimeUs,
                                        flags
                                    )
                                }
                            }
                        }

                        if ((decoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            sawDecoderOutputEOS = true
                        }
                        decoder.releaseOutputBuffer(decOutIndex, false)
                    }
                }

                // Drain encoder into muxer
                val encOutIndex = encoder.dequeueOutputBuffer(encoderBufferInfo, TIMEOUT_US)
                if (encOutIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val newFormat = encoder.outputFormat
                    muxerTrackIndex = muxer.addTrack(newFormat)
                    muxer.start()
                    muxerStarted = true
                } else if (encOutIndex >= 0) {
                    val encOutBuffer = encoder.getOutputBuffer(encOutIndex)
                    if (encOutBuffer != null && muxerStarted) {
                        if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && encoderBufferInfo.size > 0) {
                            muxer.writeSampleData(muxerTrackIndex, encOutBuffer, encoderBufferInfo)
                            if (durationUs > 0) {
                                val p = (encoderBufferInfo.presentationTimeUs.toFloat() / durationUs.toFloat()).coerceIn(0f, 0.95f)
                                onProgress(p)
                            }
                        }
                    }

                    if ((encoderBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawEncoderOutputEOS = true
                    }
                    encoder.releaseOutputBuffer(encOutIndex, false)
                }
            }

            try {
                if (muxerStarted) {
                    muxer.stop()
                    muxer.release()
                }
                encoder.stop()
                encoder.release()
                decoder.stop()
                decoder.release()
                extractor.release()
            } catch (e: Exception) {
                // Ignore cleanup error
            }

            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.AUDIO_COMPRESS,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}_${targetBitrateKbps}k.m4a",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "audio/mp4",
                durationMs = originalInfo.durationMs
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }
}
