package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

object AudioExtractorEngine {

    private const val BUFFER_SIZE = 1024 * 1024

    suspend fun extractAudio(
        context: Context,
        videoUri: Uri,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, videoUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, videoUri, "audio_ext_in", ".mp4")
        val outputFile = StorageUtils.getOutputCacheFile(context, "extracted_audio", "m4a")

        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(tempInput.absolutePath)

            val trackCount = extractor.trackCount
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1 || audioFormat == null) {
                throw IllegalStateException("No audio track found in this video")
            }

            extractor.selectTrack(audioTrackIndex)

            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackIndex = muxer.addTrack(audioFormat)
            muxer.start()

            val totalDurationUs = if (audioFormat.containsKey(MediaFormat.KEY_DURATION)) {
                audioFormat.getLong(MediaFormat.KEY_DURATION)
            } else 1L

            val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()
            var firstSampleTimeUs = -1L

            var sampleCount = 0
            while (true) {
                bufferInfo.size = extractor.readSampleData(buffer, 0)
                if (bufferInfo.size < 0) {
                    break
                }
                val sampleTime = extractor.sampleTime
                if (firstSampleTimeUs == -1L) {
                    firstSampleTimeUs = sampleTime
                }
                bufferInfo.presentationTimeUs = (sampleTime - firstSampleTimeUs).coerceAtLeast(0L)
                bufferInfo.flags = extractor.sampleFlags

                muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)
                sampleCount++
                if (sampleCount % 25 == 0 && totalDurationUs > 0) {
                    val progress = (sampleTime.toFloat() / totalDurationUs.toFloat()).coerceIn(0f, 0.95f)
                    onProgress(progress)
                }
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            extractor.release()
            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.AUDIO_EXTRACT,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}_audio.m4a",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "audio/mp4",
                durationMs = originalInfo.durationMs
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }
}
