package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.AudioTargetFormat
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioFormatConverter {

    suspend fun convertAudioFormat(
        context: Context,
        inputUri: Uri,
        targetFormat: AudioTargetFormat,
        targetBitrateKbps: Int = 192,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, inputUri, "audio_fmt_in", ".audio")
        val outputFile = StorageUtils.getOutputCacheFile(
            context,
            "converted_audio_${targetFormat.name.lowercase()}",
            targetFormat.extension
        )

        onProgress(0.1f)

        try {
            if (targetFormat == AudioTargetFormat.WAV) {
                // Decode to PCM and write WAV RIFF
                decodeToWav(tempInput, outputFile, onProgress)
            } else {
                // Encode to AAC / M4A / MP3
                encodeToContainer(tempInput, outputFile, targetFormat, targetBitrateKbps, onProgress)
            }

            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.AUDIO_FORMAT_CHANGER,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}.${targetFormat.extension}",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = targetFormat.mimeType,
                durationMs = originalInfo.durationMs
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }

    private fun decodeToWav(
        inputFile: File,
        outputFile: File,
        onProgress: (Float) -> Unit
    ) {
        val extractor = MediaExtractor()
        extractor.setDataSource(inputFile.absolutePath)

        var audioTrack = -1
        var inputFormat: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrack = i
                inputFormat = format
                break
            }
        }

        if (audioTrack == -1 || inputFormat == null) {
            throw IllegalStateException("No audio track found in file")
        }

        extractor.selectTrack(audioTrack)
        val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mp4a-latm"
        val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) inputFormat.getLong(MediaFormat.KEY_DURATION) else 1L

        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(inputFormat, null, null, 0)
        decoder.start()

        val pcmTemp = File(outputFile.parentFile, "pcm_${System.currentTimeMillis()}.raw")
        val pcmOut = FileOutputStream(pcmTemp)

        val bufferInfo = MediaCodec.BufferInfo()
        var sawInputEOS = false
        var sawOutputEOS = false
        val TIMEOUT_US = 5000L

        while (!sawOutputEOS) {
            if (!sawInputEOS) {
                val inIndex = decoder.dequeueInputBuffer(TIMEOUT_US)
                if (inIndex >= 0) {
                    val inBuffer = decoder.getInputBuffer(inIndex)
                    if (inBuffer != null) {
                        val sampleSize = extractor.readSampleData(inBuffer, 0)
                        if (sampleSize < 0) {
                            sawInputEOS = true
                            decoder.queueInputBuffer(inIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        } else {
                            val sampleTime = extractor.sampleTime
                            decoder.queueInputBuffer(inIndex, 0, sampleSize, sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
            }

            val outIndex = decoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
            if (outIndex >= 0) {
                val outBuffer = decoder.getOutputBuffer(outIndex)
                if (outBuffer != null && bufferInfo.size > 0) {
                    val chunk = ByteArray(bufferInfo.size)
                    outBuffer.position(bufferInfo.offset)
                    outBuffer.limit(bufferInfo.offset + bufferInfo.size)
                    outBuffer.get(chunk)
                    pcmOut.write(chunk)

                    if (durationUs > 0) {
                        val p = 0.1f + (0.75f * (bufferInfo.presentationTimeUs.toFloat() / durationUs.toFloat())).coerceIn(0f, 0.75f)
                        onProgress(p)
                    }
                }

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    sawOutputEOS = true
                }
                decoder.releaseOutputBuffer(outIndex, false)
            }
        }

        pcmOut.close()
        decoder.stop()
        decoder.release()
        extractor.release()

        // Write WAV header and append PCM
        val totalAudioLen = pcmTemp.length()
        val totalDataLen = totalAudioLen + 36
        val byteRate = 16 * sampleRate * channels / 8

        FileOutputStream(outputFile).use { wavOut ->
            writeWavHeader(wavOut, totalAudioLen, totalDataLen, sampleRate.toLong(), channels, byteRate.toLong())
            pcmTemp.inputStream().use { pcmIn ->
                pcmIn.copyTo(wavOut)
            }
        }
        pcmTemp.delete()
    }

    private fun writeWavHeader(
        out: FileOutputStream,
        totalAudioLen: Long,
        totalDataLen: Long,
        longSampleRate: Long,
        channels: Int,
        byteRate: Long
    ) {
        val header = ByteArray(44)
        header[0] = 'R'.code.toByte()
        header[1] = 'I'.code.toByte()
        header[2] = 'F'.code.toByte()
        header[3] = 'F'.code.toByte()
        header[4] = (totalDataLen and 0xffL).toByte()
        header[5] = ((totalDataLen shr 8) and 0xffL).toByte()
        header[6] = ((totalDataLen shr 16) and 0xffL).toByte()
        header[7] = ((totalDataLen shr 24) and 0xffL).toByte()
        header[8] = 'W'.code.toByte()
        header[9] = 'A'.code.toByte()
        header[10] = 'V'.code.toByte()
        header[11] = 'E'.code.toByte()
        header[12] = 'f'.code.toByte()
        header[13] = 'm'.code.toByte()
        header[14] = 't'.code.toByte()
        header[15] = ' '.code.toByte()
        header[16] = 16 // 16 for PCM
        header[17] = 0
        header[18] = 0
        header[19] = 0
        header[20] = 1 // PCM = 1
        header[21] = 0
        header[22] = channels.toByte()
        header[23] = 0
        header[24] = (longSampleRate and 0xffL).toByte()
        header[25] = ((longSampleRate shr 8) and 0xffL).toByte()
        header[26] = ((longSampleRate shr 16) and 0xffL).toByte()
        header[27] = ((longSampleRate shr 24) and 0xffL).toByte()
        header[28] = (byteRate and 0xffL).toByte()
        header[29] = ((byteRate shr 8) and 0xffL).toByte()
        header[30] = ((byteRate shr 16) and 0xffL).toByte()
        header[31] = ((byteRate shr 24) and 0xffL).toByte()
        header[32] = (channels * 16 / 8).toByte() // block align
        header[33] = 0
        header[34] = 16 // bits per sample
        header[35] = 0
        header[36] = 'd'.code.toByte()
        header[37] = 'a'.code.toByte()
        header[38] = 't'.code.toByte()
        header[39] = 'a'.code.toByte()
        header[40] = (totalAudioLen and 0xffL).toByte()
        header[41] = ((totalAudioLen shr 8) and 0xffL).toByte()
        header[42] = ((totalAudioLen shr 16) and 0xffL).toByte()
        header[43] = ((totalAudioLen shr 24) and 0xffL).toByte()
        out.write(header, 0, 44)
    }

    private fun encodeToContainer(
        inputFile: File,
        outputFile: File,
        targetFormat: AudioTargetFormat,
        targetBitrateKbps: Int,
        onProgress: (Float) -> Unit
    ) {
        val extractor = MediaExtractor()
        extractor.setDataSource(inputFile.absolutePath)

        var audioTrack = -1
        var inputFormat: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrack = i
                inputFormat = format
                break
            }
        }

        if (audioTrack == -1 || inputFormat == null) {
            throw IllegalStateException("No audio track found in file")
        }

        extractor.selectTrack(audioTrack)
        val inMime = inputFormat.getString(MediaFormat.KEY_MIME) ?: "audio/mp4a-latm"
        val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channels = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val durationUs = if (inputFormat.containsKey(MediaFormat.KEY_DURATION)) inputFormat.getLong(MediaFormat.KEY_DURATION) else 1L

        // Decoder
        val decoder = MediaCodec.createDecoderByType(inMime)
        decoder.configure(inputFormat, null, null, 0)
        decoder.start()

        // Encoder (AAC)
        val encoderFormat = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC,
            sampleRate,
            channels
        ).apply {
            setInteger(MediaFormat.KEY_BIT_RATE, targetBitrateKbps * 1000)
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 64 * 1024)
        }

        val encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        encoder.configure(encoderFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        encoder.start()

        val muxerFormat = when (targetFormat) {
            AudioTargetFormat.OGG -> MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG
            else -> MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
        }
        val muxer = MediaMuxer(outputFile.absolutePath, muxerFormat)
        var muxerTrackIndex = -1
        var muxerStarted = false

        val decBufferInfo = MediaCodec.BufferInfo()
        val encBufferInfo = MediaCodec.BufferInfo()

        var sawInputEOS = false
        var sawDecEOS = false
        var sawEncEOS = false
        val TIMEOUT_US = 5000L

        while (!sawEncEOS) {
            if (!sawInputEOS) {
                val inIdx = decoder.dequeueInputBuffer(TIMEOUT_US)
                if (inIdx >= 0) {
                    val inBuf = decoder.getInputBuffer(inIdx)
                    if (inBuf != null) {
                        val size = extractor.readSampleData(inBuf, 0)
                        if (size < 0) {
                            sawInputEOS = true
                            decoder.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        } else {
                            val time = extractor.sampleTime
                            decoder.queueInputBuffer(inIdx, 0, size, time, 0)
                            extractor.advance()
                        }
                    }
                }
            }

            if (!sawDecEOS) {
                val decIdx = decoder.dequeueOutputBuffer(decBufferInfo, TIMEOUT_US)
                if (decIdx >= 0) {
                    val decBuf = decoder.getOutputBuffer(decIdx)
                    if (decBuf != null && decBufferInfo.size > 0) {
                        val encInIdx = encoder.dequeueInputBuffer(TIMEOUT_US)
                        if (encInIdx >= 0) {
                            val encInBuf = encoder.getInputBuffer(encInIdx)
                            if (encInBuf != null) {
                                encInBuf.clear()
                                encInBuf.put(decBuf)
                                val flags = if ((decBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                                    sawDecEOS = true
                                    MediaCodec.BUFFER_FLAG_END_OF_STREAM
                                } else 0
                                encoder.queueInputBuffer(encInIdx, 0, decBufferInfo.size, decBufferInfo.presentationTimeUs, flags)
                            }
                        }
                    }
                    if ((decBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        sawDecEOS = true
                    }
                    decoder.releaseOutputBuffer(decIdx, false)
                }
            }

            val encIdx = encoder.dequeueOutputBuffer(encBufferInfo, TIMEOUT_US)
            if (encIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                muxerTrackIndex = muxer.addTrack(encoder.outputFormat)
                muxer.start()
                muxerStarted = true
            } else if (encIdx >= 0) {
                val encBuf = encoder.getOutputBuffer(encIdx)
                if (encBuf != null && muxerStarted) {
                    if ((encBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && encBufferInfo.size > 0) {
                        muxer.writeSampleData(muxerTrackIndex, encBuf, encBufferInfo)
                        if (durationUs > 0) {
                            val p = 0.1f + (0.85f * (encBufferInfo.presentationTimeUs.toFloat() / durationUs.toFloat())).coerceIn(0f, 0.85f)
                            onProgress(p)
                        }
                    }
                }
                if ((encBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    sawEncEOS = true
                }
                encoder.releaseOutputBuffer(encIdx, false)
            }
        }

        try {
            if (muxerStarted) {
                muxer.stop()
                muxer.release()
            }
            encoder.stop()
            encoder.release()
            decoder.stop()
            decoder.release()
            extractor.release()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
