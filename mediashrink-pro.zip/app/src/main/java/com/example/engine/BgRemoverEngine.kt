package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.sqrt

object BgRemoverEngine {

    suspend fun removeBgAuto(
        bitmap: Bitmap,
        smoothness: Float = 0.2f,
        onProgress: (Float) -> Unit = {}
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(width * height)
        output.getPixels(pixels, 0, width, 0, 0, width, height)

        onProgress(0.1f)

        // 1. Multi-point edge sampling (32 perimeter points along all edges)
        val borderColors = mutableListOf<Int>()
        val stepX = (width / 16).coerceAtLeast(1)
        val stepY = (height / 16).coerceAtLeast(1)

        for (x in 0 until width step stepX) {
            borderColors.add(pixels[x]) // top
            borderColors.add(pixels[(height - 1) * width + x]) // bottom
        }
        for (y in 0 until height step stepY) {
            borderColors.add(pixels[y * width]) // left
            borderColors.add(pixels[y * width + (width - 1)]) // right
        }

        // 2. Identify dominant background color clusters (top 3 colors)
        val clusters = clusterColors(borderColors, maxClusters = 3)

        onProgress(0.25f)

        // 3. Flood-fill from borders to only eliminate connected background
        val visited = BooleanArray(width * height)
        val isBackground = BooleanArray(width * height)
        val queue = ArrayDeque<Int>()

        // Seed with all edge pixels that match background clusters
        val baseThreshold = 42.0
        val maxDist = sqrt(255.0 * 255.0 * 3.0)

        fun matchesBg(c: Int): Boolean {
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            for (cl in clusters) {
                val cr = Color.red(cl)
                val cg = Color.green(cl)
                val cb = Color.blue(cl)
                val dist = sqrt(((r - cr) * (r - cr) + (g - cg) * (g - cg) + (b - cb) * (b - cb)).toDouble())
                if (dist <= baseThreshold) return true
            }
            return false
        }

        for (x in 0 until width) {
            val topIdx = x
            val botIdx = (height - 1) * width + x
            if (matchesBg(pixels[topIdx])) { queue.add(topIdx); visited[topIdx] = true }
            if (matchesBg(pixels[botIdx])) { queue.add(botIdx); visited[botIdx] = true }
        }
        for (y in 0 until height) {
            val leftIdx = y * width
            val rightIdx = y * width + (width - 1)
            if (!visited[leftIdx] && matchesBg(pixels[leftIdx])) { queue.add(leftIdx); visited[leftIdx] = true }
            if (!visited[rightIdx] && matchesBg(pixels[rightIdx])) { queue.add(rightIdx); visited[rightIdx] = true }
        }

        // BFS traversal
        while (!queue.isEmpty()) {
            val idx = queue.poll()
            isBackground[idx] = true

            val cx = idx % width
            val cy = idx / width

            val neighbors = intArrayOf(
                if (cx > 0) idx - 1 else -1,
                if (cx < width - 1) idx + 1 else -1,
                if (cy > 0) idx - width else -1,
                if (cy < height - 1) idx + width else -1
            )

            for (n in neighbors) {
                if (n != -1 && !visited[n]) {
                    visited[n] = true
                    if (matchesBg(pixels[n])) {
                        queue.add(n)
                    }
                }
            }
        }

        onProgress(0.7f)

        // 4. Alpha matting: set background to transparent and soften transition edges
        val featherDist = (smoothness * 20f).toInt().coerceAtLeast(1)
        for (y in 0 until height) {
            for (x in 0 until width) {
                val idx = y * width + x
                if (isBackground[idx]) {
                    pixels[idx] = 0x00000000
                }
            }
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        onProgress(1.0f)
        output
    }

    private fun clusterColors(colors: List<Int>, maxClusters: Int): List<Int> {
        if (colors.isEmpty()) return listOf(Color.WHITE)
        val result = mutableListOf<Int>()
        for (c in colors) {
            var found = false
            for (ex in result) {
                val dr = Color.red(c) - Color.red(ex)
                val dg = Color.green(c) - Color.green(ex)
                val db = Color.blue(c) - Color.blue(ex)
                if (dr * dr + dg * dg + db * db < 1600) { // dist < 40
                    found = true
                    break
                }
            }
            if (!found) {
                result.add(c)
                if (result.size >= maxClusters) break
            }
        }
        return if (result.isNotEmpty()) result else listOf(colors[0])
    }

    suspend fun removeBgChroma(
        bitmap: Bitmap,
        targetColor: Int,
        tolerance: Float = 0.35f,
        feather: Float = 0.15f
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height
        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(width * height)
        output.getPixels(pixels, 0, width, 0, 0, width, height)

        val targetR = Color.red(targetColor)
        val targetG = Color.green(targetColor)
        val targetB = Color.blue(targetColor)
        val maxDist = sqrt(255.0 * 255.0 * 3.0)

        val thresholdDist = tolerance * maxDist
        val featherDist = feather * maxDist

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)

            val dist = sqrt(
                ((r - targetR) * (r - targetR) + (g - targetG) * (g - targetG) + (b - targetB) * (b - targetB)).toDouble()
            )

            if (dist <= thresholdDist) {
                pixels[i] = 0x00000000
            } else if (dist < thresholdDist + featherDist && featherDist > 0) {
                val alphaRatio = ((dist - thresholdDist) / featherDist).coerceIn(0.0, 1.0)
                val alpha = (alphaRatio * 255).toInt()
                pixels[i] = Color.argb(alpha, r, g, b)
            }
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        output
    }

    suspend fun removeBgMagicWand(
        bitmap: Bitmap,
        startX: Int,
        startY: Int,
        tolerance: Float = 0.25f
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = bitmap.width
        val height = bitmap.height
        val clampedX = startX.coerceIn(0, width - 1)
        val clampedY = startY.coerceIn(0, height - 1)

        val output = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        val pixels = IntArray(width * height)
        output.getPixels(pixels, 0, width, 0, 0, width, height)

        val targetPixel = pixels[clampedY * width + clampedX]
        val tR = Color.red(targetPixel)
        val tG = Color.green(targetPixel)
        val tB = Color.blue(targetPixel)

        val maxDist = sqrt(255.0 * 255.0 * 3.0)
        val thresholdDist = tolerance * maxDist

        val visited = BooleanArray(width * height)
        val queue = ArrayDeque<Int>()
        queue.add(clampedY * width + clampedX)
        visited[clampedY * width + clampedX] = true

        while (!queue.isEmpty()) {
            val idx = queue.poll()
            pixels[idx] = 0x00000000

            val cx = idx % width
            val cy = idx / width

            val neighbors = intArrayOf(
                if (cx > 0) idx - 1 else -1,
                if (cx < width - 1) idx + 1 else -1,
                if (cy > 0) idx - width else -1,
                if (cy < height - 1) idx + width else -1
            )

            for (n in neighbors) {
                if (n != -1 && !visited[n]) {
                    val c = pixels[n]
                    if (Color.alpha(c) > 0) {
                        val r = Color.red(c)
                        val g = Color.green(c)
                        val b = Color.blue(c)
                        val dist = sqrt(((r - tR) * (r - tR) + (g - tG) * (g - tG) + (b - tB) * (b - tB)).toDouble())
                        if (dist <= thresholdDist) {
                            visited[n] = true
                            queue.add(n)
                        }
                    }
                }
            }
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        output
    }

    fun applyBrushStroke(
        workingBitmap: Bitmap,
        originalBitmap: Bitmap,
        centerX: Float,
        centerY: Float,
        radius: Float,
        isRepair: Boolean
    ): Bitmap {
        val width = workingBitmap.width
        val height = workingBitmap.height
        val output = workingBitmap.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)

        if (isRepair) {
            val minX = (centerX - radius).toInt().coerceIn(0, width - 1)
            val maxX = (centerX + radius).toInt().coerceIn(0, width - 1)
            val minY = (centerY - radius).toInt().coerceIn(0, height - 1)
            val maxY = (centerY + radius).toInt().coerceIn(0, height - 1)
            val r2 = radius * radius

            val curPixels = IntArray(width * height)
            output.getPixels(curPixels, 0, width, 0, 0, width, height)
            val origPixels = IntArray(width * height)
            originalBitmap.getPixels(origPixels, 0, width, 0, 0, width, height)

            for (y in minY..maxY) {
                for (x in minX..maxX) {
                    val dx = x - centerX
                    val dy = y - centerY
                    if (dx * dx + dy * dy <= r2) {
                        val idx = y * width + x
                        curPixels[idx] = origPixels[idx]
                    }
                }
            }
            output.setPixels(curPixels, 0, width, 0, 0, width, height)
        } else {
            val paint = Paint().apply {
                isAntiAlias = true
                xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            }
            canvas.drawCircle(centerX, centerY, radius, paint)
        }

        return output
    }

    fun createCompositeWithBackdrop(
        cutoutBitmap: Bitmap,
        originalBitmap: Bitmap,
        backdropColor: Int?,
        isBlurPortrait: Boolean
    ): Bitmap {
        val width = cutoutBitmap.width
        val height = cutoutBitmap.height
        val result = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)

        if (isBlurPortrait) {
            // Create soft blurred background from original
            val downsampled = Bitmap.createScaledBitmap(originalBitmap, (width / 8).coerceAtLeast(16), (height / 8).coerceAtLeast(16), true)
            val blurredBg = Bitmap.createScaledBitmap(downsampled, width, height, true)
            canvas.drawBitmap(blurredBg, 0f, 0f, null)
            downsampled.recycle()
            blurredBg.recycle()
        } else if (backdropColor != null && backdropColor != Color.TRANSPARENT) {
            canvas.drawColor(backdropColor)
        }

        // Draw isolated subject over backdrop
        canvas.drawBitmap(cutoutBitmap, 0f, 0f, null)
        return result
    }
}
