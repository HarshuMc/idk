package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

object GifProcessor {

    suspend fun compressGif(
        context: Context,
        inputUri: Uri,
        frameSkipStep: Int = 2, // 1 = keep all, 2 = keep every 2nd frame (50% reduction)
        scaleFactor: Float = 0.75f,
        maxColors: Int = 128,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val outputFile = StorageUtils.getOutputCacheFile(context, "optimized_gif", "gif")

        onProgress(0.1f)

        // Decode input frames
        // In Android, animated GIF frames can be decoded via ImageDecoder on API 28+ or extracted from stream
        val frames = mutableListOf<Bitmap>()
        val delays = mutableListOf<Int>()

        try {
            // Read all bytes from input URI
            val bytes = context.contentResolver.openInputStream(inputUri)?.use { it.readBytes() }
                ?: throw IllegalStateException("Could not read GIF data")

            val decodedFrames = decodeGifFrames(bytes)
            if (decodedFrames.isNotEmpty()) {
                frames.addAll(decodedFrames.map { it.first })
                delays.addAll(decodedFrames.map { it.second })
            } else {
                // Fallback to static bitmap decode if not multi-frame
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp != null) {
                    frames.add(bmp)
                    delays.add(100) // 100ms
                }
            }
        } catch (e: Exception) {
            // Fallback decode
            context.contentResolver.openInputStream(inputUri)?.use { stream ->
                BitmapFactory.decodeStream(stream)?.let {
                    frames.add(it)
                    delays.add(100)
                }
            }
        }

        if (frames.isEmpty()) {
            throw IllegalStateException("Failed to decode any frames from GIF")
        }

        onProgress(0.3f)

        // Filter frames based on skip step
        val selectedFrames = mutableListOf<Bitmap>()
        val selectedDelays = mutableListOf<Int>()

        for (i in frames.indices) {
            if (i % frameSkipStep == 0) {
                val orig = frames[i]
                val scaledW = (orig.width * scaleFactor).toInt().coerceAtLeast(1)
                val scaledH = (orig.height * scaleFactor).toInt().coerceAtLeast(1)

                val scaled = if (scaledW != orig.width || scaledH != orig.height) {
                    Bitmap.createScaledBitmap(orig, scaledW, scaledH, true)
                } else {
                    orig
                }
                selectedFrames.add(scaled)
                val adjustedDelay = (delays.getOrElse(i) { 100 } * frameSkipStep)
                selectedDelays.add(adjustedDelay)
            }
        }

        onProgress(0.5f)

        // Encode to output GIF
        FileOutputStream(outputFile).use { outStream ->
            val encoder = SimpleGifEncoder()
            encoder.start(outStream)
            encoder.setRepeat(0) // Infinite loop

            for (i in selectedFrames.indices) {
                encoder.setDelay(selectedDelays[i])
                encoder.addFrame(selectedFrames[i], maxColors)
                val p = 0.5f + (0.45f * (i + 1).toFloat() / selectedFrames.size.toFloat())
                onProgress(p)
            }

            encoder.finish()
        }

        // Clean up bitmaps
        for (f in frames) {
            if (!f.isRecycled) f.recycle()
        }
        for (f in selectedFrames) {
            if (!f.isRecycled) f.recycle()
        }

        onProgress(1.0f)

        ProcessedResult(
            toolType = ToolType.GIF_COMPRESS,
            originalFileName = originalInfo.fileName,
            outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}_optimized.gif",
            originalSizeBytes = originalInfo.fileSizeBytes,
            outputSizeBytes = outputFile.length(),
            outputUri = Uri.fromFile(outputFile),
            outputMimeType = "image/gif"
        )
    }

    private fun decodeGifFrames(bytes: ByteArray): List<Pair<Bitmap, Int>> {
        val list = mutableListOf<Pair<Bitmap, Int>>()
        try {
            var pos = 0
            // Check GIF87a or GIF89a
            if (bytes.size < 13 || bytes[0] != 'G'.code.toByte() || bytes[1] != 'I'.code.toByte() || bytes[2] != 'F'.code.toByte()) {
                return emptyList()
            }
            pos = 6
            val width = (bytes[pos].toInt() and 0xFF) or ((bytes[pos + 1].toInt() and 0xFF) shl 8)
            val height = (bytes[pos + 2].toInt() and 0xFF) or ((bytes[pos + 3].toInt() and 0xFF) shl 8)
            val packed = bytes[pos + 4].toInt() and 0xFF
            val gctFlag = (packed and 0x80) != 0
            val gctSize = 2 shl (packed and 0x07)
            pos += 7

            if (gctFlag) {
                pos += 3 * gctSize
            }

            var currentDelay = 100 // ms
            while (pos < bytes.size) {
                val blockType = bytes[pos].toInt() and 0xFF
                if (blockType == 0x3B) { // Trailer
                    break
                } else if (blockType == 0x21) { // Extension
                    pos++
                    if (pos >= bytes.size) break
                    val extLabel = bytes[pos].toInt() and 0xFF
                    pos++
                    if (extLabel == 0xF9) { // Graphic Control Extension
                        val blockSize = bytes[pos].toInt() and 0xFF
                        pos++
                        if (blockSize >= 4 && pos + 3 < bytes.size) {
                            val delayCs = (bytes[pos + 1].toInt() and 0xFF) or ((bytes[pos + 2].toInt() and 0xFF) shl 8)
                            currentDelay = (delayCs * 10).coerceAtLeast(20)
                        }
                        pos += blockSize
                        while (pos < bytes.size && (bytes[pos].toInt() and 0xFF) != 0) {
                            pos += (bytes[pos].toInt() and 0xFF) + 1
                        }
                        pos++
                    } else {
                        // Skip other extensions
                        while (pos < bytes.size && (bytes[pos].toInt() and 0xFF) != 0) {
                            pos += (bytes[pos].toInt() and 0xFF) + 1
                        }
                        pos++
                    }
                } else if (blockType == 0x2C) { // Image Descriptor
                    // Use standard Android decoder from this position or frame snapshot
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) {
                        list.add(Pair(bmp, currentDelay))
                    }
                    break
                } else {
                    pos++
                }
            }
        } catch (e: Exception) {
            // Ignore
        }
        return list
    }

    private class SimpleGifEncoder {
        private var out: OutputStream? = null
        private var width = 0
        private var height = 0
        private var delay = 100 // ms
        private var repeat = 0 // loop count
        private var started = false

        fun setDelay(ms: Int) {
            delay = ms
        }

        fun setRepeat(loopCount: Int) {
            repeat = loopCount
        }

        fun start(os: OutputStream): Boolean {
            out = os
            started = true
            writeString("GIF89a")
            return true
        }

        fun addFrame(bitmap: Bitmap, maxColors: Int): Boolean {
            if (!started || out == null) return false
            width = bitmap.width
            height = bitmap.height

            val pixels = IntArray(width * height)
            bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

            // Quantize to maxColors (e.g. 128 or 256)
            val quantizer = Quantizer(pixels, maxColors)
            val indexedPixels = quantizer.indexedPixels
            val colorTable = quantizer.colorTable

            writeLogicalScreenDescriptor()
            writeGraphicControlExtension()
            writeNetscapeExtension()
            writeImageDescriptor()
            writeColorTable(colorTable)
            writeImageData(indexedPixels, colorTable.size)

            return true
        }

        fun finish(): Boolean {
            if (!started) return false
            try {
                out?.write(0x3B) // GIF trailer
                out?.flush()
            } catch (e: Exception) {
                return false
            }
            return true
        }

        private fun writeString(s: String) {
            for (ch in s) {
                out?.write(ch.code)
            }
        }

        private fun writeShort(value: Int) {
            out?.write(value and 0xFF)
            out?.write((value shr 8) and 0xFF)
        }

        private fun writeLogicalScreenDescriptor() {
            writeShort(width)
            writeShort(height)
            out?.write(0x70) // No Global Color Table, 8-bit color resolution
            out?.write(0)    // Background color index
            out?.write(0)    // Pixel aspect ratio
        }

        private fun writeGraphicControlExtension() {
            out?.write(0x21) // Extension introducer
            out?.write(0xF9) // GCE label
            out?.write(4)    // Block size
            out?.write(0)    // Packed fields: disposal 0, user input 0, transparent 0
            val delayCs = (delay / 10).coerceAtLeast(2)
            writeShort(delayCs)
            out?.write(0)    // Transparent color index
            out?.write(0)    // Block terminator
        }

        private fun writeNetscapeExtension() {
            out?.write(0x21)
            out?.write(0xFF)
            out?.write(11)
            writeString("NETSCAPE2.0")
            out?.write(3)
            out?.write(1)
            writeShort(repeat)
            out?.write(0)
        }

        private fun writeImageDescriptor() {
            out?.write(0x2C) // Image separator
            writeShort(0)    // Left
            writeShort(0)    // Top
            writeShort(width)
            writeShort(height)
            out?.write(0x87) // Local Color Table flag, 256 colors
        }

        private fun writeColorTable(table: List<Int>) {
            for (i in 0 until 256) {
                val rgb = if (i < table.size) table[i] else 0
                val r = (rgb shr 16) and 0xFF
                val g = (rgb shr 8) and 0xFF
                val b = rgb and 0xFF
                out?.write(r)
                out?.write(g)
                out?.write(b)
            }
        }

        private fun writeImageData(indexedPixels: ByteArray, colorCount: Int) {
            val minCodeSize = 8
            out?.write(minCodeSize)

            // LZW encoder
            val lzw = LzwEncoder(width, height, indexedPixels, minCodeSize)
            lzw.encode(out!!)
            out?.write(0) // Block terminator
        }
    }

    private class Quantizer(pixels: IntArray, maxColors: Int) {
        val colorTable = mutableListOf<Int>()
        val indexedPixels = ByteArray(pixels.size)

        init {
            // Frequency map
            val colorFreq = HashMap<Int, Int>()
            for (c in pixels) {
                val rgb = c and 0x00FFFFFF
                colorFreq[rgb] = (colorFreq[rgb] ?: 0) + 1
            }

            // Top colors
            val sortedColors = colorFreq.entries.sortedByDescending { it.value }
            val chosen = sortedColors.take(maxColors.coerceAtMost(256)).map { it.key }
            colorTable.addAll(chosen)
            if (colorTable.isEmpty()) colorTable.add(0)

            // Map each pixel to nearest color
            for (i in pixels.indices) {
                val rgb = pixels[i] and 0x00FFFFFF
                var nearestIdx = 0
                var minDist = Int.MAX_VALUE

                val r1 = (rgb shr 16) and 0xFF
                val g1 = (rgb shr 8) and 0xFF
                val b1 = rgb and 0xFF

                for (j in colorTable.indices) {
                    val crgb = colorTable[j]
                    val r2 = (crgb shr 16) and 0xFF
                    val g2 = (crgb shr 8) and 0xFF
                    val b2 = crgb and 0xFF

                    val dr = r1 - r2
                    val dg = g1 - g2
                    val db = b1 - b2
                    val dist = dr * dr + dg * dg + db * db
                    if (dist < minDist) {
                        minDist = dist
                        nearestIdx = j
                        if (dist == 0) break
                    }
                }
                indexedPixels[i] = nearestIdx.toByte()
            }
        }
    }

    private class LzwEncoder(
        private val width: Int,
        private val height: Int,
        private val pixels: ByteArray,
        private val initCodeSize: Int
    ) {
        fun encode(os: OutputStream) {
            val clearCode = 1 shl initCodeSize
            val eofCode = clearCode + 1
            var codeSize = initCodeSize + 1
            var curCode = 0
            var curBits = 0
            val accum = ByteArray(256)
            var aCount = 0

            fun flushPacket() {
                if (aCount > 0) {
                    os.write(aCount)
                    os.write(accum, 0, aCount)
                    aCount = 0
                }
            }

            fun writeBits(code: Int, bits: Int) {
                curCode = curCode or (code shl curBits)
                curBits += bits
                while (curBits >= 8) {
                    accum[aCount++] = (curCode and 0xFF).toByte()
                    if (aCount >= 254) flushPacket()
                    curCode = curCode shr 8
                    curBits -= 8
                }
            }

            writeBits(clearCode, codeSize)

            var curPos = 0
            val totalPixels = width * height
            while (curPos < totalPixels) {
                val index = pixels[curPos].toInt() and 0xFF
                writeBits(index, codeSize)
                curPos++
                if (codeSize < 12 && (curPos % 512 == 0)) {
                    // Periodic clear
                    writeBits(clearCode, codeSize)
                    codeSize = initCodeSize + 1
                }
            }

            writeBits(eofCode, codeSize)

            // Flush remaining bits
            if (curBits > 0) {
                accum[aCount++] = (curCode and 0xFF).toByte()
                curCode = 0
                curBits = 0
            }
            flushPacket()
        }
    }
}
