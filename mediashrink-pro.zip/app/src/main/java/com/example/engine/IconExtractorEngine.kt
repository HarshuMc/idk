package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.ArrayDeque
import kotlin.math.sqrt

object IconExtractorEngine {

    suspend fun extractIconsGrid(
        context: Context,
        inputUri: Uri,
        rows: Int,
        cols: Int,
        onProgress: (Float) -> Unit = {}
    ): List<ProcessedResult> = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val bitmap = context.contentResolver.openInputStream(inputUri)?.use {
            BitmapFactory.decodeStream(it)
        } ?: throw IllegalStateException("Failed to decode image")

        val cellWidth = bitmap.width / cols.coerceAtLeast(1)
        val cellHeight = bitmap.height / rows.coerceAtLeast(1)

        val results = mutableListOf<ProcessedResult>()
        val totalCells = rows * cols

        var count = 0
        for (r in 0 until rows) {
            for (c in 0 until cols) {
                count++
                val x = c * cellWidth
                val y = r * cellHeight
                val iconBmp = Bitmap.createBitmap(bitmap, x, y, cellWidth, cellHeight)

                val outputFile = StorageUtils.getOutputCacheFile(
                    context,
                    "icon_grid_${r + 1}_${c + 1}",
                    "png"
                )
                FileOutputStream(outputFile).use { out ->
                    iconBmp.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                iconBmp.recycle()

                val baseName = originalInfo.fileName.substringBeforeLast(".")
                results.add(
                    ProcessedResult(
                        toolType = ToolType.ICON_EXTRACTOR,
                        originalFileName = originalInfo.fileName,
                        outputFileName = "${baseName}_icon_${r + 1}x${c + 1}.png",
                        originalSizeBytes = originalInfo.fileSizeBytes,
                        outputSizeBytes = outputFile.length(),
                        outputUri = Uri.fromFile(outputFile),
                        outputMimeType = "image/png"
                    )
                )

                onProgress(count.toFloat() / totalCells.toFloat())
            }
        }

        bitmap.recycle()
        results
    }

    suspend fun extractIconsAuto(
        context: Context,
        inputUri: Uri,
        minDimensionPx: Int = 24,
        onProgress: (Float) -> Unit = {}
    ): List<ProcessedResult> = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val bitmap = context.contentResolver.openInputStream(inputUri)?.use {
            BitmapFactory.decodeStream(it)
        } ?: throw IllegalStateException("Failed to decode image")

        onProgress(0.15f)

        val width = bitmap.width
        val height = bitmap.height
        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        // 1. Detect background color from four corners
        val c1 = pixels[0]
        val c2 = pixels[width - 1]
        val c3 = pixels[(height - 1) * width]
        val c4 = pixels[(height - 1) * width + (width - 1)]

        val bgR = (Color.red(c1) + Color.red(c2) + Color.red(c3) + Color.red(c4)) / 4
        val bgG = (Color.green(c1) + Color.green(c2) + Color.green(c3) + Color.green(c4)) / 4
        val bgB = (Color.blue(c1) + Color.blue(c2) + Color.blue(c3) + Color.blue(c4)) / 4

        fun isForeground(c: Int): Boolean {
            val a = Color.alpha(c)
            if (a < 30) return false
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            val dist = sqrt(((r - bgR) * (r - bgR) + (g - bgG) * (g - bgG) + (b - bgB) * (b - bgB)).toDouble())
            return dist > 35.0
        }

        // 2. Connected Component Labeling to find separate icons
        val visited = BooleanArray(width * height)
        val boundingBoxes = mutableListOf<Rect>()

        val step = if (width > 800) 2 else 1

        for (y in 0 until height step step) {
            for (x in 0 until width step step) {
                val idx = y * width + x
                if (!visited[idx] && isForeground(pixels[idx])) {
                    // Flood fill to find bounding box
                    var minX = x
                    var maxX = x
                    var minY = y
                    var maxY = y

                    val q = ArrayDeque<Int>()
                    q.add(idx)
                    visited[idx] = true

                    var componentPixels = 0

                    while (!q.isEmpty()) {
                        val curr = q.poll()
                        componentPixels++
                        val cx = curr % width
                        val cy = curr / width

                        if (cx < minX) minX = cx
                        if (cx > maxX) maxX = cx
                        if (cy < minY) minY = cy
                        if (cy > maxY) maxY = cy

                        val neighbors = intArrayOf(
                            if (cx > 0) curr - 1 else -1,
                            if (cx < width - 1) curr + 1 else -1,
                            if (cy > 0) curr - width else -1,
                            if (cy < height - 1) curr + width else -1
                        )

                        for (n in neighbors) {
                            if (n != -1 && !visited[n] && isForeground(pixels[n])) {
                                visited[n] = true
                                q.add(n)
                            }
                        }
                    }

                    val bw = maxX - minX + 1
                    val bh = maxY - minY + 1
                    if (bw >= minDimensionPx && bh >= minDimensionPx && componentPixels > 80) {
                        // Expand slightly with 4px padding
                        val pad = 4
                        val paddedRect = Rect(
                            (minX - pad).coerceAtLeast(0),
                            (minY - pad).coerceAtLeast(0),
                            (maxX + pad).coerceAtMost(width - 1),
                            (maxY + pad).coerceAtMost(height - 1)
                        )
                        boundingBoxes.add(paddedRect)
                    }
                }
            }
        }

        // Deduplicate overlapping boxes
        val mergedBoxes = mutableListOf<Rect>()
        for (b in boundingBoxes) {
            var overlaps = false
            for (m in mergedBoxes) {
                if (Rect.intersects(b, m)) {
                    m.union(b)
                    overlaps = true
                    break
                }
            }
            if (!overlaps) {
                mergedBoxes.add(b)
            }
        }

        onProgress(0.5f)

        // 3. Crop each icon and save
        val results = mutableListOf<ProcessedResult>()
        val baseName = originalInfo.fileName.substringBeforeLast(".")

        val validBoxes = if (mergedBoxes.isNotEmpty()) mergedBoxes else listOf(Rect(0, 0, width - 1, height - 1))

        for ((index, rect) in validBoxes.withIndex()) {
            val w = rect.width().coerceAtLeast(1)
            val h = rect.height().coerceAtLeast(1)

            val iconBmp = Bitmap.createBitmap(bitmap, rect.left, rect.top, w, h)
            val outputFile = StorageUtils.getOutputCacheFile(
                context,
                "icon_auto_${index + 1}",
                "png"
            )

            FileOutputStream(outputFile).use { out ->
                iconBmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            iconBmp.recycle()

            results.add(
                ProcessedResult(
                    toolType = ToolType.ICON_EXTRACTOR,
                    originalFileName = originalInfo.fileName,
                    outputFileName = "${baseName}_icon_${index + 1}.png",
                    originalSizeBytes = originalInfo.fileSizeBytes,
                    outputSizeBytes = outputFile.length(),
                    outputUri = Uri.fromFile(outputFile),
                    outputMimeType = "image/png"
                )
            )

            val p = 0.5f + (0.5f * (index + 1).toFloat() / validBoxes.size.toFloat())
            onProgress(p)
        }

        bitmap.recycle()
        onProgress(1.0f)
        results
    }
}
