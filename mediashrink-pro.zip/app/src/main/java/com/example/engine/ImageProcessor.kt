package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.media.ExifInterface
import com.example.model.ImageOutputFormat
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object ImageProcessor {

    suspend fun compressImage(
        context: Context,
        inputUri: Uri,
        quality: Int, // 10..100
        resolutionScale: Float, // 0.25f..1.0f
        format: ImageOutputFormat,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        onProgress(0.2f)

        // 1. Decode original bitmap bounds
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        context.contentResolver.openInputStream(inputUri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, options)
        }

        val origW = options.outWidth
        val origH = options.outHeight

        // 2. Compute sample size if scaling down significantly to prevent OutOfMemory
        val targetW = (origW * resolutionScale).toInt().coerceAtLeast(1)
        val targetH = (origH * resolutionScale).toInt().coerceAtLeast(1)

        var sampleSize = 1
        while ((origW / (sampleSize * 2)) >= targetW && (origH / (sampleSize * 2)) >= targetH) {
            sampleSize *= 2
        }

        val decodeOptions = BitmapFactory.Options().apply {
            inSampleSize = sampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        onProgress(0.4f)
        var bitmap: Bitmap? = context.contentResolver.openInputStream(inputUri)?.use { stream ->
            BitmapFactory.decodeStream(stream, null, decodeOptions)
        } ?: throw IllegalStateException("Could not decode image")

        // 3. Fix EXIF orientation
        try {
            context.contentResolver.openInputStream(inputUri)?.use { stream ->
                val exif = ExifInterface(stream)
                val orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL
                )
                val matrix = Matrix()
                when (orientation) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.postScale(1f, -1f)
                }
                if (!matrix.isIdentity) {
                    val rotated = Bitmap.createBitmap(
                        bitmap!!, 0, 0, bitmap!!.width, bitmap!!.height, matrix, true
                    )
                    if (rotated != bitmap) {
                        bitmap!!.recycle()
                        bitmap = rotated
                    }
                }
            }
        } catch (e: Exception) {
            // Orientation fallback
        }

        onProgress(0.6f)

        // 4. Exact scale if needed
        val currentW = bitmap!!.width
        val currentH = bitmap!!.height
        if (currentW != targetW || currentH != targetH) {
            val scaled = Bitmap.createScaledBitmap(bitmap!!, targetW, targetH, true)
            if (scaled != bitmap) {
                bitmap!!.recycle()
                bitmap = scaled
            }
        }

        onProgress(0.8f)

        // 5. Output file
        val outputPrefix = "compressed_${System.currentTimeMillis()}"
        val outputFile = StorageUtils.getOutputCacheFile(context, outputPrefix, format.extension)

        val compressFormat = when (format) {
            ImageOutputFormat.JPEG -> Bitmap.CompressFormat.JPEG
            ImageOutputFormat.PNG -> Bitmap.CompressFormat.PNG
            ImageOutputFormat.WEBP -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Bitmap.CompressFormat.WEBP_LOSSY
                } else {
                    @Suppress("DEPRECATION")
                    Bitmap.CompressFormat.WEBP
                }
            }
        }

        FileOutputStream(outputFile).use { outStream ->
            bitmap!!.compress(compressFormat, quality.coerceIn(1, 100), outStream)
        }

        bitmap!!.recycle()
        onProgress(1.0f)

        val outputSize = outputFile.length()

        ProcessedResult(
            toolType = ToolType.IMAGE_COMPRESS,
            originalFileName = originalInfo.fileName,
            outputFileName = outputFile.name,
            originalSizeBytes = originalInfo.fileSizeBytes,
            outputSizeBytes = outputSize,
            outputUri = Uri.fromFile(outputFile),
            outputMimeType = format.mimeType
        )
    }
}
