package com.example.engine

import android.graphics.Bitmap
import android.graphics.Color
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.sqrt

object ObjectEraserEngine {

    suspend fun eraseObject(
        source: Bitmap,
        mask: Bitmap,
        onProgress: (Float) -> Unit = {}
    ): Bitmap = withContext(Dispatchers.Default) {
        val width = source.width
        val height = source.height

        val result = source.copy(Bitmap.Config.ARGB_8888, true)
        val srcPixels = IntArray(width * height)
        val maskPixels = IntArray(width * height)

        result.getPixels(srcPixels, 0, width, 0, 0, width, height)
        mask.getPixels(maskPixels, 0, width, 0, 0, width, height)

        onProgress(0.1f)

        // Find bounding box of mask to only process the necessary sub-region
        var minX = width
        var maxX = 0
        var minY = height
        var maxY = 0
        var totalMasked = 0

        val isHole = BooleanArray(width * height)

        for (y in 0 until height) {
            val rowOffset = y * width
            for (x in 0 until width) {
                val idx = rowOffset + x
                val a = Color.alpha(maskPixels[idx])
                val r = Color.red(maskPixels[idx])
                if (a > 25 || r > 80) {
                    isHole[idx] = true
                    totalMasked++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
        }

        if (totalMasked == 0) {
            onProgress(1.0f)
            return@withContext result
        }

        // Expand bounds by 16px padding
        val pad = 16
        minX = (minX - pad).coerceAtLeast(0)
        maxX = (maxX + pad).coerceAtMost(width - 1)
        minY = (minY - pad).coerceAtLeast(0)
        maxY = (maxY + pad).coerceAtMost(height - 1)

        onProgress(0.25f)

        // Dilation: 2px boundary expansion to prevent outline fringing
        val dilatedHole = isHole.clone()
        for (y in minY + 1 until maxY) {
            val row = y * width
            for (x in minX + 1 until maxX) {
                val idx = row + x
                if (isHole[idx]) {
                    dilatedHole[idx - 1] = true
                    dilatedHole[idx + 1] = true
                    dilatedHole[idx - width] = true
                    dilatedHole[idx + width] = true
                }
            }
        }

        // Collect boundary reference pixels (known pixels directly touching the hole)
        val boundaryPixels = mutableListOf<Int>()
        for (y in minY..maxY) {
            val row = y * width
            for (x in minX..maxX) {
                val idx = row + x
                if (!dilatedHole[idx]) {
                    // Check if adjacent to hole
                    val touchesHole = (x > 0 && dilatedHole[idx - 1]) ||
                            (x < width - 1 && dilatedHole[idx + 1]) ||
                            (y > 0 && dilatedHole[idx - width]) ||
                            (y < height - 1 && dilatedHole[idx + width])
                    if (touchesHole) {
                        boundaryPixels.add(idx)
                    }
                }
            }
        }

        if (boundaryPixels.isEmpty()) {
            onProgress(1.0f)
            return@withContext result
        }

        onProgress(0.45f)

        // Telea Fast Marching Inward Inpainting
        val remainingHole = dilatedHole.clone()
        var remainingCount = 0
        for (y in minY..maxY) {
            val row = y * width
            for (x in minX..maxX) {
                if (remainingHole[row + x]) remainingCount++
            }
        }

        val initialRemaining = remainingCount
        var iter = 0
        val maxIterations = 80
        val patchRadius = 4

        while (remainingCount > 0 && iter < maxIterations) {
            iter++
            val waveFront = mutableListOf<Int>()

            for (y in minY..maxY) {
                val row = y * width
                for (x in minX..maxX) {
                    val idx = row + x
                    if (remainingHole[idx]) {
                        val hasKnownNeighbor = (x > 0 && !remainingHole[idx - 1]) ||
                                (x < width - 1 && !remainingHole[idx + 1]) ||
                                (y > 0 && !remainingHole[idx - width]) ||
                                (y < height - 1 && !remainingHole[idx + width])
                        if (hasKnownNeighbor) {
                            waveFront.add(idx)
                        }
                    }
                }
            }

            if (waveFront.isEmpty()) break

            for (idx in waveFront) {
                val cx = idx % width
                val cy = idx / width

                var sumR = 0.0
                var sumG = 0.0
                var sumB = 0.0
                var weightSum = 0.0

                for (dy in -patchRadius..patchRadius) {
                    val ny = cy + dy
                    if (ny < minY || ny > maxY) continue
                    val nRow = ny * width
                    for (dx in -patchRadius..patchRadius) {
                        val nx = cx + dx
                        if (nx < minX || nx > maxX) continue

                        val nIdx = nRow + nx
                        if (!remainingHole[nIdx]) {
                            val distSq = (dx * dx + dy * dy).toDouble() + 0.1
                            val w = 1.0 / distSq
                            val c = srcPixels[nIdx]
                            sumR += Color.red(c) * w
                            sumG += Color.green(c) * w
                            sumB += Color.blue(c) * w
                            weightSum += w
                        }
                    }
                }

                if (weightSum > 0) {
                    val r = (sumR / weightSum).toInt().coerceIn(0, 255)
                    val g = (sumG / weightSum).toInt().coerceIn(0, 255)
                    val b = (sumB / weightSum).toInt().coerceIn(0, 255)
                    srcPixels[idx] = Color.rgb(r, g, b)
                }
                remainingHole[idx] = false
            }

            remainingCount -= waveFront.size
            val p = 0.45f + (0.5f * (1.0f - (remainingCount.toFloat() / initialRemaining.toFloat()))).coerceIn(0f, 0.5f)
            onProgress(p)
        }

        result.setPixels(srcPixels, 0, width, 0, 0, width, height)
        onProgress(1.0f)
        result
    }
}
