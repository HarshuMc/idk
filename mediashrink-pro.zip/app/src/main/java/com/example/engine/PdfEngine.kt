package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

data class PdfPageModel(
    val pageIndex: Int,
    val originalPageIndex: Int,
    val thumbnail: Bitmap,
    val width: Int,
    val height: Int,
    var rotationDegrees: Int = 0
)

object PdfEngine {

    /**
     * Extracts and renders thumbnails for all pages of a PDF document
     */
    suspend fun loadPdfPages(context: Context, pdfUri: Uri): List<PdfPageModel> = withContext(Dispatchers.IO) {
        val pages = mutableListOf<PdfPageModel>()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            pfd = context.contentResolver.openFileDescriptor(pdfUri, "r")
            if (pfd != null) {
                renderer = PdfRenderer(pfd)
                val count = renderer.pageCount
                for (i in 0 until count) {
                    val page = renderer.openPage(i)
                    // Render reasonable thumbnail (e.g., max 400px width/height)
                    val scale = 360f / maxOf(page.width, page.height).toFloat()
                    val thumbW = (page.width * scale).toInt().coerceAtLeast(1)
                    val thumbH = (page.height * scale).toInt().coerceAtLeast(1)

                    val bmp = Bitmap.createBitmap(thumbW, thumbH, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    pages.add(
                        PdfPageModel(
                            pageIndex = i,
                            originalPageIndex = i,
                            thumbnail = bmp,
                            width = page.width,
                            height = page.height
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }

        pages
    }

    /**
     * Reconstructs, compresses, and saves a PDF with user-specified page ordering, rotation, and quality
     */
    suspend fun exportPdf(
        context: Context,
        originalPdfUri: Uri,
        orderedPages: List<PdfPageModel>,
        qualityPercent: Int = 85,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val outputFile = StorageUtils.getOutputCacheFile(context, "pdf_master", "pdf")
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        val doc = PdfDocument()

        try {
            pfd = context.contentResolver.openFileDescriptor(originalPdfUri, "r")
            renderer = if (pfd != null) PdfRenderer(pfd) else null

            val total = orderedPages.size
            orderedPages.forEachIndexed { index, pageModel ->
                onProgress((index + 1).toFloat() / total.toFloat())

                if (renderer != null && pageModel.originalPageIndex < renderer.pageCount) {
                    val srcPage = renderer.openPage(pageModel.originalPageIndex)
                    val pw = srcPage.width
                    val ph = srcPage.height

                    // Page info
                    val pageInfo = PdfDocument.PageInfo.Builder(pw, ph, index + 1).create()
                    val newPage = doc.startPage(pageInfo)
                    val canvas: Canvas = newPage.canvas

                    // Render original page to a high-res bitmap
                    val renderBmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
                    renderBmp.eraseColor(Color.WHITE)
                    srcPage.render(renderBmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                    srcPage.close()

                    // Apply rotation if needed
                    val finalBmp = if (pageModel.rotationDegrees != 0) {
                        val matrix = Matrix().apply { postRotate(pageModel.rotationDegrees.toFloat()) }
                        Bitmap.createBitmap(renderBmp, 0, 0, renderBmp.width, renderBmp.height, matrix, true)
                    } else {
                        renderBmp
                    }

                    canvas.drawBitmap(finalBmp, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
                    doc.finishPage(newPage)
                }
            }

            FileOutputStream(outputFile).use { out ->
                doc.writeTo(out)
            }
        } finally {
            try { doc.close() } catch (_: Exception) {}
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }

        outputFile
    }

    /**
     * Merges multiple PDF files into a single unified document
     */
    suspend fun mergePdfs(
        context: Context,
        pdfUris: List<Uri>,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val outputFile = StorageUtils.getOutputCacheFile(context, "pdf_merged", "pdf")
        val doc = PdfDocument()
        var pageCounter = 1

        val totalDocs = pdfUris.size
        pdfUris.forEachIndexed { docIdx, uri ->
            onProgress((docIdx + 1).toFloat() / totalDocs.toFloat())
            var pfd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                pfd = context.contentResolver.openFileDescriptor(uri, "r")
                if (pfd != null) {
                    renderer = PdfRenderer(pfd)
                    for (i in 0 until renderer.pageCount) {
                        val page = renderer.openPage(i)
                        val pageInfo = PdfDocument.PageInfo.Builder(page.width, page.height, pageCounter++).create()
                        val newPage = doc.startPage(pageInfo)
                        val bmp = Bitmap.createBitmap(page.width, page.height, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                        page.close()
                        newPage.canvas.drawBitmap(bmp, 0f, 0f, Paint(Paint.FILTER_BITMAP_FLAG))
                        doc.finishPage(newPage)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                try { renderer?.close() } catch (_: Exception) {}
                try { pfd?.close() } catch (_: Exception) {}
            }
        }

        FileOutputStream(outputFile).use { out ->
            doc.writeTo(out)
        }
        doc.close()
        outputFile
    }
}
