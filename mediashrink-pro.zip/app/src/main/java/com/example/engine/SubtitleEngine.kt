package com.example.engine

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

data class SubtitleCue(
    val id: Int,
    var startTimeMs: Long,
    var endTimeMs: Long,
    var text: String
) {
    fun formatSrtTimestamp(ms: Long): String {
        val hours = ms / 3600000
        val minutes = (ms % 3600000) / 60000
        val seconds = (ms % 60000) / 1000
        val millis = ms % 1000
        return String.format(Locale.US, "%02d:%02d:%02d,%03d", hours, minutes, seconds, millis)
    }

    fun toSrtBlock(): String {
        return "$id\n${formatSrtTimestamp(startTimeMs)} --> ${formatSrtTimestamp(endTimeMs)}\n$text\n\n"
    }
}

object SubtitleEngine {

    /**
     * Parses an existing .srt text string or file into structured cues
     */
    fun parseSrt(srtContent: String): List<SubtitleCue> {
        val cues = mutableListOf<SubtitleCue>()
        val blocks = srtContent.replace("\r\n", "\n").replace("\r", "\n").split("\n\n")

        for (block in blocks) {
            val lines = block.trim().lines()
            if (lines.size >= 2) {
                val timeLineIndex = if (lines[0].toIntOrNull() != null && lines.size >= 3) 1 else 0
                val timeLine = lines[timeLineIndex]

                if (timeLine.contains("-->")) {
                    val times = timeLine.split("-->")
                    val startMs = parseTimestampToMs(times[0].trim())
                    val endMs = parseTimestampToMs(times[1].trim())
                    val textLines = lines.drop(timeLineIndex + 1).joinToString("\n")

                    cues.add(
                        SubtitleCue(
                            id = cues.size + 1,
                            startTimeMs = startMs,
                            endTimeMs = endMs,
                            text = textLines
                        )
                    )
                }
            }
        }
        return cues
    }

    private fun parseTimestampToMs(timeStr: String): Long {
        try {
            val parts = timeStr.replace(',', '.').split(':')
            if (parts.size == 3) {
                val hours = parts[0].toLong()
                val minutes = parts[1].toLong()
                val secParts = parts[2].split('.')
                val seconds = secParts[0].toLong()
                val millis = if (secParts.size > 1) secParts[1].padEnd(3, '0').take(3).toLong() else 0L
                return hours * 3600000 + minutes * 60000 + seconds * 1000 + millis
            }
        } catch (_: Exception) {}
        return 0L
    }

    /**
     * Exports a sidecar subtitle file (.srt) formatted for VLC / standard media players
     */
    suspend fun exportSidecarSrt(
        context: Context,
        videoFileName: String,
        cues: List<SubtitleCue>,
        offsetMs: Long = 0L
    ): File = withContext(Dispatchers.IO) {
        val baseName = videoFileName.substringBeforeLast(".")
        val outputFile = StorageUtils.getOutputCacheFile(context, "${baseName}_synced", "srt")

        val sb = StringBuilder()
        cues.sortedBy { it.startTimeMs }.forEachIndexed { index, cue ->
            val adjustedStart = (cue.startTimeMs + offsetMs).coerceAtLeast(0)
            val adjustedEnd = (cue.endTimeMs + offsetMs).coerceAtLeast(adjustedStart + 500)
            val adjustedCue = cue.copy(id = index + 1, startTimeMs = adjustedStart, endTimeMs = adjustedEnd)
            sb.append(adjustedCue.toSrtBlock())
        }

        FileOutputStream(outputFile).use { out ->
            out.write(sb.toString().toByteArray(Charsets.UTF_8))
        }

        outputFile
    }

    /**
     * Generates a sample subtitle template for a video
     */
    fun createDefaultCues(durationMs: Long): List<SubtitleCue> {
        val maxDuration = if (durationMs > 0) durationMs else 15000L
        return listOf(
            SubtitleCue(1, 1000L, 4000L, "Welcome to the video presentation"),
            SubtitleCue(2, 4500L, 8500L, "Powered by Media Craft Pro Audio & Subtitle Engine"),
            SubtitleCue(3, 9000L, (maxDuration - 1000).coerceAtLeast(10000L), "Enjoy crystal clear media playback with external CC")
        )
    }
}
