package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import com.example.model.VideoTargetContainer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

object VideoCodecChanger {

    private const val BUFFER_SIZE = 1024 * 1024 * 2

    suspend fun convertVideoCodecAndContainer(
        context: Context,
        inputUri: Uri,
        targetContainer: VideoTargetContainer,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, inputUri, "codec_in", ".video")
        val outputFile = StorageUtils.getOutputCacheFile(
            context,
            "converted_${targetContainer.name.lowercase()}",
            targetContainer.extension
        )

        onProgress(0.1f)

        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(tempInput.absolutePath)

            val muxerFormat = when (targetContainer) {
                VideoTargetContainer.THREE_GP -> MediaMuxer.OutputFormat.MUXER_OUTPUT_3GPP
                VideoTargetContainer.WEBM -> MediaMuxer.OutputFormat.MUXER_OUTPUT_WEBM
                else -> MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            }

            val muxer = MediaMuxer(outputFile.absolutePath, muxerFormat)
            val trackMap = HashMap<Int, Int>()

            var videoDurationUs = 0L

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val outTrack = muxer.addTrack(format)
                    trackMap[i] = outTrack
                    if (mime.startsWith("video/") && format.containsKey(MediaFormat.KEY_DURATION)) {
                        videoDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                    }
                }
            }

            muxer.start()

            val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()

            var sampleCount = 0
            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val muxerTrack = trackMap[trackIndex]
                if (muxerTrack != null) {
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) break

                    bufferInfo.presentationTimeUs = extractor.sampleTime
                    bufferInfo.flags = extractor.sampleFlags

                    muxer.writeSampleData(muxerTrack, buffer, bufferInfo)

                    sampleCount++
                    if (sampleCount % 30 == 0 && videoDurationUs > 0) {
                        val p = 0.1f + (0.85f * (bufferInfo.presentationTimeUs.toFloat() / videoDurationUs.toFloat())).coerceIn(0f, 0.85f)
                        onProgress(p)
                    }
                }
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            extractor.release()

            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.VIDEO_CODEC_CHANGER,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}.${targetContainer.extension}",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = targetContainer.mimeType,
                durationMs = originalInfo.durationMs
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }
}
