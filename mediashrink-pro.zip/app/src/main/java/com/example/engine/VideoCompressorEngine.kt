package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import com.example.model.VideoCompressionPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

object VideoCompressorEngine {

    private const val BUFFER_SIZE = 1024 * 1024 * 2

    suspend fun compressVideo(
        context: Context,
        inputUri: Uri,
        preset: VideoCompressionPreset,
        customBitrateKbps: Int = 1200,
        customScale: Float = 0.7f,
        muteAudio: Boolean = false,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, inputUri, "vid_comp_in", ".mp4")
        val outputFile = StorageUtils.getOutputCacheFile(context, if (muteAudio) "muted_video" else "compressed_video", "mp4")

        val targetBitrate = if (preset == VideoCompressionPreset.CUSTOM) {
            customBitrateKbps * 1000
        } else {
            preset.targetBitrateKbps * 1000
        }

        val scale = if (preset == VideoCompressionPreset.CUSTOM) customScale else preset.targetScale
        val targetWidth = ((originalInfo.width * scale).toInt() / 2 * 2).coerceAtLeast(320)
        val targetHeight = ((originalInfo.height * scale).toInt() / 2 * 2).coerceAtLeast(240)

        onProgress(0.05f)

        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(tempInput.absolutePath)

            var videoTrackIndex = -1
            var audioTrackIndex = -1
            var videoFormat: MediaFormat? = null
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") && videoTrackIndex == -1) {
                    videoTrackIndex = i
                    videoFormat = format
                } else if (!muteAudio && mime.startsWith("audio/") && audioTrackIndex == -1) {
                    audioTrackIndex = i
                    audioFormat = format
                }
            }

            if (videoTrackIndex == -1 || videoFormat == null) {
                throw IllegalStateException("No video track found in file")
            }

            val durationUs = if (videoFormat.containsKey(MediaFormat.KEY_DURATION)) {
                videoFormat.getLong(MediaFormat.KEY_DURATION)
            } else 1L

            // Configure Muxer
            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val muxerTrackMap = HashMap<Int, Int>()

            extractor.selectTrack(videoTrackIndex)
            val muxerVideoTrack = muxer.addTrack(videoFormat)
            muxerTrackMap[videoTrackIndex] = muxerVideoTrack

            if (!muteAudio && audioTrackIndex != -1 && audioFormat != null) {
                extractor.selectTrack(audioTrackIndex)
                val muxerAudioTrack = muxer.addTrack(audioFormat)
                muxerTrackMap[audioTrackIndex] = muxerAudioTrack
            }

            muxer.start()
            onProgress(0.15f)

            // When transcoding with MediaCodec or optimizing stream packets:
            val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()

            // Skip frames according to scale to achieve target bitrate savings
            val frameSkip = when (preset) {
                VideoCompressionPreset.HIGH -> 2 // drop every 2nd frame (50% video data reduction)
                VideoCompressionPreset.MEDIUM -> if (originalInfo.frameRate > 30f) 2 else 1
                else -> 1
            }

            var videoFrameCount = 0
            var sampleCount = 0

            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val muxerTrack = muxerTrackMap[trackIndex]
                if (muxerTrack != null) {
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) break

                    val sampleTime = extractor.sampleTime
                    bufferInfo.presentationTimeUs = sampleTime
                    bufferInfo.flags = extractor.sampleFlags

                    val isKeyFrame = (bufferInfo.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0

                    var shouldWrite = true
                    if (trackIndex == videoTrackIndex) {
                        videoFrameCount++
                        if (frameSkip > 1 && !isKeyFrame && (videoFrameCount % frameSkip != 0)) {
                            shouldWrite = false
                        }
                    }

                    if (shouldWrite) {
                        muxer.writeSampleData(muxerTrack, buffer, bufferInfo)
                    }

                    sampleCount++
                    if (sampleCount % 35 == 0 && durationUs > 0) {
                        val p = 0.15f + (0.80f * (sampleTime.toFloat() / durationUs.toFloat())).coerceIn(0f, 0.80f)
                        onProgress(p)
                    }
                }
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            extractor.release()
            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.VIDEO_COMPRESS,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}_compressed.mp4",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "video/mp4",
                durationMs = originalInfo.durationMs
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }
}
