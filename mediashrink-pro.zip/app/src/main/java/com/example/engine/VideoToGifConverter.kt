package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

object VideoToGifConverter {

    suspend fun convertVideoToGif(
        context: Context,
        videoUri: Uri,
        startMs: Long = 0L,
        endMs: Long = 5000L,
        targetFps: Int = 12,
        targetWidth: Int = 400,
        maxColors: Int = 128,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, videoUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, videoUri, "vid_to_gif_in", ".mp4")
        val outputFile = StorageUtils.getOutputCacheFile(context, "video_converted", "gif")

        onProgress(0.05f)

        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(tempInput.absolutePath)

            val durationUs = (originalInfo.durationMs * 1000L).coerceAtLeast(1000L)
            val clipStartUs = (startMs * 1000L).coerceAtLeast(0L)
            val clipEndUs = (endMs * 1000L).coerceAtMost(durationUs)
            val effectiveDurationUs = (clipEndUs - clipStartUs).coerceAtLeast(100000L)

            val frameIntervalUs = 1000000L / targetFps.coerceIn(5, 25)
            val totalFrames = ((effectiveDurationUs / frameIntervalUs) + 1).toInt().coerceIn(2, 60)

            val frames = mutableListOf<Bitmap>()
            val frameDelayMs = (1000 / targetFps).coerceAtLeast(40)

            for (i in 0 until totalFrames) {
                val currentUs = clipStartUs + (i * frameIntervalUs)
                if (currentUs > clipEndUs) break

                val frameBitmap = retriever.getFrameAtTime(
                    currentUs,
                    MediaMetadataRetriever.OPTION_CLOSEST
                ) ?: retriever.getFrameAtTime(currentUs)

                if (frameBitmap != null) {
                    val aspect = frameBitmap.height.toFloat() / frameBitmap.width.toFloat()
                    val targetHeight = (targetWidth * aspect).toInt().coerceAtLeast(1)

                    val scaled = if (frameBitmap.width != targetWidth || frameBitmap.height != targetHeight) {
                        val s = Bitmap.createScaledBitmap(frameBitmap, targetWidth, targetHeight, true)
                        if (s != frameBitmap) frameBitmap.recycle()
                        s
                    } else {
                        frameBitmap
                    }
                    frames.add(scaled)
                }

                val p = 0.05f + (0.45f * (i + 1).toFloat() / totalFrames.toFloat())
                onProgress(p)
            }

            retriever.release()

            if (frames.isEmpty()) {
                throw IllegalStateException("Failed to extract video frames")
            }

            // Encode frames to GIF
            FileOutputStream(outputFile).use { outStream ->
                // Write GIF Header
                writeGifStream(outStream, frames, frameDelayMs, maxColors) { encodeProgress ->
                    val overallProgress = 0.5f + (0.5f * encodeProgress)
                    onProgress(overallProgress)
                }
            }

            for (f in frames) {
                if (!f.isRecycled) f.recycle()
            }

            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.VIDEO_TO_GIF,
                originalFileName = originalInfo.fileName,
                outputFileName = "${originalInfo.fileName.substringBeforeLast(".")}.gif",
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "image/gif",
                durationMs = (endMs - startMs).coerceAtLeast(0L)
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }

    private fun writeGifStream(
        out: FileOutputStream,
        frames: List<Bitmap>,
        delayMs: Int,
        maxColors: Int,
        onFrameEncoded: (Float) -> Unit
    ) {
        val width = frames.first().width
        val height = frames.first().height

        fun writeString(s: String) {
            for (ch in s) out.write(ch.code)
        }

        fun writeShort(v: Int) {
            out.write(v and 0xFF)
            out.write((v shr 8) and 0xFF)
        }

        // Header
        writeString("GIF89a")
        // Logical Screen Descriptor
        writeShort(width)
        writeShort(height)
        out.write(0x70) // 8-bit, no global color table
        out.write(0)
        out.write(0)

        // Netscape application block for looping
        out.write(0x21)
        out.write(0xFF)
        out.write(11)
        writeString("NETSCAPE2.0")
        out.write(3)
        out.write(1)
        writeShort(0) // loop infinite
        out.write(0)

        for ((idx, bmp) in frames.withIndex()) {
            val pixels = IntArray(width * height)
            bmp.getPixels(pixels, 0, width, 0, 0, width, height)

            val (colorTable, indexedPixels) = quantizeFrame(pixels, maxColors)

            // Graphic Control Extension
            out.write(0x21)
            out.write(0xF9)
            out.write(4)
            out.write(0)
            val delayCs = (delayMs / 10).coerceAtLeast(2)
            writeShort(delayCs)
            out.write(0)
            out.write(0)

            // Image Descriptor
            out.write(0x2C)
            writeShort(0)
            writeShort(0)
            writeShort(width)
            writeShort(height)
            out.write(0x87) // Local Color Table flag, 256 colors

            // Color Table
            for (i in 0 until 256) {
                val rgb = if (i < colorTable.size) colorTable[i] else 0
                out.write((rgb shr 16) and 0xFF)
                out.write((rgb shr 8) and 0xFF)
                out.write(rgb and 0xFF)
            }

            // LZW Image Data
            out.write(8) // min code size
            encodeLzw(out, indexedPixels, width * height, 8)
            out.write(0)

            onFrameEncoded((idx + 1).toFloat() / frames.size.toFloat())
        }

        out.write(0x3B) // Trailer
        out.flush()
    }

    private fun quantizeFrame(pixels: IntArray, maxColors: Int): Pair<List<Int>, ByteArray> {
        val freq = HashMap<Int, Int>()
        for (c in pixels) {
            val rgb = c and 0x00FFFFFF
            freq[rgb] = (freq[rgb] ?: 0) + 1
        }
        val sorted = freq.entries.sortedByDescending { it.value }
        val table = sorted.take(maxColors.coerceAtMost(256)).map { it.key }.toMutableList()
        if (table.isEmpty()) table.add(0)

        val indexed = ByteArray(pixels.size)
        for (i in pixels.indices) {
            val rgb = pixels[i] and 0x00FFFFFF
            val r1 = (rgb shr 16) and 0xFF
            val g1 = (rgb shr 8) and 0xFF
            val b1 = rgb and 0xFF

            var bestIdx = 0
            var bestDist = Int.MAX_VALUE

            for (j in table.indices) {
                val crgb = table[j]
                val dr = r1 - ((crgb shr 16) and 0xFF)
                val dg = g1 - ((crgb shr 8) and 0xFF)
                val db = b1 - (crgb and 0xFF)
                val dist = dr * dr + dg * dg + db * db
                if (dist < bestDist) {
                    bestDist = dist
                    bestIdx = j
                    if (dist == 0) break
                }
            }
            indexed[i] = bestIdx.toByte()
        }
        return Pair(table, indexed)
    }

    private fun encodeLzw(out: FileOutputStream, pixels: ByteArray, totalLen: Int, initCodeSize: Int) {
        val clearCode = 1 shl initCodeSize
        val eofCode = clearCode + 1
        var codeSize = initCodeSize + 1
        var curCode = 0
        var curBits = 0
        val accum = ByteArray(256)
        var aCount = 0

        fun flushPacket() {
            if (aCount > 0) {
                out.write(aCount)
                out.write(accum, 0, aCount)
                aCount = 0
            }
        }

        fun writeBits(code: Int, bits: Int) {
            curCode = curCode or (code shl curBits)
            curBits += bits
            while (curBits >= 8) {
                accum[aCount++] = (curCode and 0xFF).toByte()
                if (aCount >= 254) flushPacket()
                curCode = curCode shr 8
                curBits -= 8
            }
        }

        writeBits(clearCode, codeSize)
        var pos = 0
        while (pos < totalLen) {
            val idx = pixels[pos].toInt() and 0xFF
            writeBits(idx, codeSize)
            pos++
            if (codeSize < 12 && (pos % 512 == 0)) {
                writeBits(clearCode, codeSize)
                codeSize = initCodeSize + 1
            }
        }
        writeBits(eofCode, codeSize)
        if (curBits > 0) {
            accum[aCount++] = (curCode and 0xFF).toByte()
        }
        flushPacket()
    }
}
