package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import com.example.model.ProcessedResult
import com.example.model.ToolType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer

object VideoTrimmerAndSplitter {

    private const val BUFFER_SIZE = 1024 * 1024 * 2 // 2MB buffer

    suspend fun trimVideo(
        context: Context,
        inputUri: Uri,
        startMs: Long,
        endMs: Long,
        onProgress: (Float) -> Unit = {}
    ): ProcessedResult = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val tempInput = StorageUtils.copyUriToTempFile(context, inputUri, "trim_in", ".mp4")
        val outputFile = StorageUtils.getOutputCacheFile(context, "trimmed", "mp4")

        try {
            val extractor = MediaExtractor()
            extractor.setDataSource(tempInput.absolutePath)

            val trackCount = extractor.trackCount
            val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val indexMap = HashMap<Int, Int>()

            var videoTrackIndex = -1
            var videoDurationUs = 0L

            for (i in 0 until trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    val muxerTrackIndex = muxer.addTrack(format)
                    indexMap[i] = muxerTrackIndex
                    if (mime.startsWith("video/")) {
                        videoTrackIndex = i
                        if (format.containsKey(MediaFormat.KEY_DURATION)) {
                            videoDurationUs = format.getLong(MediaFormat.KEY_DURATION)
                        }
                    }
                }
            }

            muxer.start()

            val startUs = (startMs * 1000L).coerceAtLeast(0L)
            val endUs = (endMs * 1000L).coerceAtMost(if (videoDurationUs > 0) videoDurationUs else Long.MAX_VALUE)
            val totalTrimDurationUs = (endUs - startUs).coerceAtLeast(1L)

            // Seek to start sync frame
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)

            val buffer = ByteBuffer.allocateDirect(BUFFER_SIZE)
            val bufferInfo = MediaCodec.BufferInfo()
            val trackOffsetUs = HashMap<Int, Long>()

            var sampleCount = 0
            while (true) {
                val trackIndex = extractor.sampleTrackIndex
                if (trackIndex < 0) break

                val muxerTrackIndex = indexMap[trackIndex]
                if (muxerTrackIndex != null) {
                    bufferInfo.size = extractor.readSampleData(buffer, 0)
                    if (bufferInfo.size < 0) {
                        break
                    }
                    val sampleTime = extractor.sampleTime
                    if (sampleTime > endUs) {
                        // Reached end of trim region for this stream
                        if (trackIndex == videoTrackIndex) {
                            break
                        }
                    } else if (sampleTime >= startUs) {
                        if (!trackOffsetUs.containsKey(trackIndex)) {
                            trackOffsetUs[trackIndex] = sampleTime
                        }
                        val baseOffset = trackOffsetUs[trackIndex] ?: 0L
                        bufferInfo.presentationTimeUs = (sampleTime - baseOffset).coerceAtLeast(0L)
                        bufferInfo.flags = extractor.sampleFlags

                        muxer.writeSampleData(muxerTrackIndex, buffer, bufferInfo)

                        sampleCount++
                        if (sampleCount % 30 == 0) {
                            val currentProgress = ((sampleTime - startUs).toFloat() / totalTrimDurationUs).coerceIn(0f, 0.95f)
                            onProgress(currentProgress)
                        }
                    }
                }
                extractor.advance()
            }

            muxer.stop()
            muxer.release()
            extractor.release()
            onProgress(1.0f)

            ProcessedResult(
                toolType = ToolType.VIDEO_TRIM,
                originalFileName = originalInfo.fileName,
                outputFileName = outputFile.name,
                originalSizeBytes = originalInfo.fileSizeBytes,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "video/mp4",
                durationMs = (endMs - startMs).coerceAtLeast(0L)
            )
        } finally {
            if (tempInput.exists()) tempInput.delete()
        }
    }

    suspend fun splitVideo(
        context: Context,
        inputUri: Uri,
        chunkDurationMs: Long,
        onProgress: (Float, Int, Int) -> Unit = { _, _, _ -> }
    ): List<ProcessedResult> = withContext(Dispatchers.IO) {
        val originalInfo = StorageUtils.getMediaInfo(context, inputUri)
        val totalDurationMs = originalInfo.durationMs.coerceAtLeast(chunkDurationMs)
        val numParts = Math.ceil(totalDurationMs.toDouble() / chunkDurationMs.toDouble()).toInt().coerceAtLeast(1)

        val results = mutableListOf<ProcessedResult>()

        for (i in 0 until numParts) {
            val partStartMs = i * chunkDurationMs
            val partEndMs = ((i + 1) * chunkDurationMs).coerceAtMost(totalDurationMs)

            val partProgressCallback: (Float) -> Unit = { partProgress ->
                val overallProgress = (i.toFloat() + partProgress) / numParts.toFloat()
                onProgress(overallProgress, i + 1, numParts)
            }

            val result = trimVideo(
                context = context,
                inputUri = inputUri,
                startMs = partStartMs,
                endMs = partEndMs,
                onProgress = partProgressCallback
            )

            val partFile = File(result.outputUri.path ?: "")
            val renamedPartName = "${originalInfo.fileName.substringBeforeLast(".")}_part_${i + 1}.mp4"
            results.add(
                result.copy(
                    toolType = ToolType.VIDEO_SPLIT,
                    outputFileName = renamedPartName,
                    durationMs = partEndMs - partStartMs
                )
            )
        }

        results
    }
}
