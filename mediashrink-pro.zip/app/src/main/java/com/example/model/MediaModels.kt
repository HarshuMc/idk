package com.example.model

import android.net.Uri

enum class ToolType(
    val title: String,
    val subtitle: String,
    val iconName: String,
    val route: String,
    val category: String = "Compression"
) {
    // --- Documents ---
    PDF_MASTER(
        title = "PDF Master & Merger",
        subtitle = "Visual page drag/reorder, multi-doc merge & compression",
        iconName = "picture_as_pdf",
        route = "pdf_master",
        category = "Documents"
    ),

    // --- Compression ---
    VIDEO_COMPRESS(
        title = "Video Compressor & Mute",
        subtitle = "Hardware H.264 shrink with direct audio mute toggle",
        iconName = "videocam",
        route = "video_compress",
        category = "Compression"
    ),
    IMAGE_COMPRESS(
        title = "Image Compressor",
        subtitle = "Reduce JPEG, PNG & WebP with bulk queue support",
        iconName = "image",
        route = "image_compress",
        category = "Compression"
    ),
    GIF_COMPRESS(
        title = "GIF Optimizer & WebM",
        subtitle = "Frame drop, color quantization & WebM animation loops",
        iconName = "animation",
        route = "gif_compress",
        category = "Compression"
    ),
    AUDIO_COMPRESS(
        title = "Audio Compressor",
        subtitle = "Bulk compress MP3, AAC, WAV by custom bitrates",
        iconName = "music_note",
        route = "audio_compress",
        category = "Compression"
    ),

    // --- AI Suite ---
    AUDIO_DENOISER(
        title = "Audio Denoiser & Enhancer",
        subtitle = "Neural vocal isolation & background hiss/hum clean-up",
        iconName = "graphic_eq",
        route = "audio_denoiser",
        category = "AI Suite"
    ),
    BG_REMOVER(
        title = "AI Background Remover",
        subtitle = "Auto AI cutout, Chroma eyedropper & portrait blur",
        iconName = "auto_fix_high",
        route = "bg_remover",
        category = "AI Suite"
    ),
    OBJECT_ERASER(
        title = "AI Object Eraser",
        subtitle = "Brush over unwanted objects with neural inpainting",
        iconName = "cleaning_services",
        route = "object_eraser",
        category = "AI Suite"
    ),
    ICON_EXTRACTOR(
        title = "Icon Extractor",
        subtitle = "Auto-detect or grid-slice icons from PNG, JPG & WebP",
        iconName = "grid_view",
        route = "icon_extractor",
        category = "Documents"
    ),

    // --- Video & Audio ---
    SUBTITLE_INJECTOR(
        title = "External Subtitle Injector",
        subtitle = "Add synced sidecar .srt/.vtt subtitles for VLC/CC",
        iconName = "closed_caption",
        route = "subtitle_injector",
        category = "Video & Audio"
    ),
    AUDIO_FORMAT_CHANGER(
        title = "Audio Format Changer",
        subtitle = "Convert between MP3, AAC, M4A, WAV, FLAC & OGG",
        iconName = "transform",
        route = "audio_format",
        category = "Video & Audio"
    ),
    AUDIO_EXTRACT(
        title = "Audio Extractor",
        subtitle = "Extract pristine audio tracks from any video",
        iconName = "headphones",
        route = "audio_extract",
        category = "Video & Audio"
    ),
    VIDEO_TO_GIF(
        title = "Video to GIF",
        subtitle = "Convert video clip to smooth animated GIF",
        iconName = "gif_box",
        route = "video_to_gif",
        category = "Video & Audio"
    ),
    VIDEO_CODEC_CHANGER(
        title = "Video Codec & Format",
        subtitle = "Convert container (MP4, MKV, 3GP) and codec profiles",
        iconName = "settings_suggest",
        route = "video_codec",
        category = "Video & Audio"
    ),
    VIDEO_TRIM(
        title = "Video Cutter & Trim",
        subtitle = "Lossless stream-copy trimming in milliseconds",
        iconName = "content_cut",
        route = "video_trim",
        category = "Video & Audio"
    ),
    VIDEO_SPLIT(
        title = "Video Splitter",
        subtitle = "Split into 30s WhatsApp status or custom parts",
        iconName = "call_split",
        route = "video_split",
        category = "Video & Audio"
    )
}

enum class ImageOutputFormat(val extension: String, val mimeType: String, val displayName: String) {
    JPEG("jpg", "image/jpeg", "JPEG"),
    WEBP("webp", "image/webp", "WebP (Smallest)"),
    PNG("png", "image/png", "PNG (Lossless)")
}

enum class AudioTargetFormat(val extension: String, val mimeType: String, val displayName: String) {
    AAC("aac", "audio/aac", "AAC (Compact)"),
    M4A("m4a", "audio/mp4", "M4A (Apple / High Fidelity)"),
    MP3("mp3", "audio/mpeg", "MP3 (Universal)"),
    WAV("wav", "audio/x-wav", "WAV (Uncompressed PCM)"),
    OGG("ogg", "audio/ogg", "OGG Vorbis")
}

enum class VideoTargetContainer(val extension: String, val mimeType: String, val displayName: String) {
    MP4("mp4", "video/mp4", "MP4 (Universal standard)"),
    MKV("mkv", "video/x-matroska", "MKV (Matroska)"),
    THREE_GP("3gp", "video/3gpp", "3GP (Mobile legacy)"),
    WEBM("webm", "video/webm", "WebM (Open Web)")
}

enum class VideoCompressionPreset(
    val displayName: String,
    val description: String,
    val targetScale: Float,
    val targetBitrateKbps: Int
) {
    LOW(
        displayName = "Light (90% Quality)",
        description = "Slight reduction, maximum visual crispness",
        targetScale = 0.9f,
        targetBitrateKbps = 2500
    ),
    MEDIUM(
        displayName = "Balanced (Recommended)",
        description = "Great quality, ~50% - 65% size reduction",
        targetScale = 0.7f,
        targetBitrateKbps = 1400
    ),
    HIGH(
        displayName = "Maximum Compression",
        description = "Aggressive shrink for quick email or chat sharing",
        targetScale = 0.5f,
        targetBitrateKbps = 800
    ),
    CUSTOM(
        displayName = "Custom Settings",
        description = "Choose exact target resolution and bitrate",
        targetScale = 1.0f,
        targetBitrateKbps = 1200
    )
}

enum class BgRemoverMode(val displayName: String, val icon: String, val description: String) {
    AUTO_AI("Auto AI", "auto_awesome", "Intelligent foreground subject isolation"),
    CHROMA_KEY("Chroma Key", "color_lens", "Remove green/blue screen or custom color background"),
    MAGIC_WAND("Magic Wand", "auto_fix_normal", "Tap to flood-erase continuous matching color tones"),
    MANUAL_BRUSH("Precision Brush", "brush", "Manually paint away background with adjustable radius"),
    REPAIR("Repair Tool", "healing", "Brush over erased regions to restore original pixels")
}

data class SourceMediaInfo(
    val uri: Uri,
    val fileName: String,
    val fileSizeBytes: Long,
    val mimeType: String,
    val width: Int = 0,
    val height: Int = 0,
    val durationMs: Long = 0,
    val bitrate: Long = 0,
    val frameRate: Float = 0f
)

data class ProcessedResult(
    val id: String = System.currentTimeMillis().toString(),
    val toolType: ToolType,
    val originalFileName: String,
    val outputFileName: String,
    val originalSizeBytes: Long,
    val outputSizeBytes: Long,
    val savedBytes: Long = (originalSizeBytes - outputSizeBytes).coerceAtLeast(0),
    val savingsPercent: Int = if (originalSizeBytes > 0) {
        (((originalSizeBytes - outputSizeBytes).toFloat() / originalSizeBytes.toFloat()) * 100).toInt().coerceIn(0, 99)
    } else 0,
    val outputUri: Uri,
    val outputMimeType: String,
    val durationMs: Long = 0,
    val timestamp: Long = System.currentTimeMillis()
)

data class ProcessingProgress(
    val isProcessing: Boolean = false,
    val progressPercent: Float = 0f,
    val currentStage: String = "",
    val itemsCompleted: Int = 0,
    val totalItems: Int = 1,
    val error: String? = null
)
