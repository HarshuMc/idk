package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioDenoiserScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var hissReduction by remember { mutableFloatStateOf(80f) }
    var vocalBoostDb by remember { mutableFloatStateOf(4.0f) }
    var noiseGateFloor by remember { mutableFloatStateOf(0.04f) }

    val pickAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.onMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Audio Denoiser & Enhancer", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Neural Vocal Isolation & Hiss Filter", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (selectedMedia != null) {
                        IconButton(onClick = { viewModel.clearSelection() }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear", tint = DarkTextSecondary)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                EmptyMediaSelector(
                    title = "Select Audio or Voice Recording",
                    subtitle = "Filter out persistent air-conditioner hiss, PC fan hum, room reverberation, and boost vocal clarity.",
                    buttonText = "Choose Audio File",
                    icon = Icons.Default.GraphicEq,
                    onSelect = { pickAudioLauncher.launch("audio/*") }
                )
            } else {
                MediaFileCard(
                    mediaInfo = selectedMedia!!,
                    onRemove = { viewModel.clearSelection() }
                )

                // Futuristic Spectral Frequency Visualizer
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = IndigoViolet.copy(alpha = 0.5f)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "SPECTRAL BAND MONITOR",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = IndigoViolet,
                                letterSpacing = 1.sp
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NeonEmerald.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("DSP ACTIVE", color = NeonEmerald, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Visual simulated spectral bars
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF090D16))
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.BottomCenter
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                val barCount = 28
                                val barWidth = (size.width / barCount) - 4f
                                val heights = listOf(
                                    0.15f, 0.25f, 0.40f, 0.70f, 0.95f, 0.85f, 0.90f, 0.80f, 0.65f,
                                    0.50f, 0.35f, 0.25f, 0.20f, 0.15f, 0.12f, 0.10f, 0.08f, 0.05f,
                                    0.04f, 0.03f, 0.02f, 0.02f, 0.01f, 0.01f, 0.01f, 0.01f, 0.01f, 0.01f
                                )
                                for (i in 0 until barCount) {
                                    val hFrac = heights.getOrElse(i) { 0.1f }
                                    val x = i * (barWidth + 4f)
                                    val barH = size.height * hFrac
                                    drawRect(
                                        brush = Brush.verticalGradient(
                                            listOf(ElectricCyan, IndigoViolet)
                                        ),
                                        topLeft = Offset(x, size.height - barH),
                                        size = Size(barWidth, barH)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("100Hz (Rumble)", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted, fontSize = 10.sp)
                            Text("1kHz - 4kHz (Speech)", style = MaterialTheme.typography.labelSmall, color = ElectricCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("8kHz+ (Hiss)", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted, fontSize = 10.sp)
                        }
                    }
                }

                // Noise Gate & Vocal Enhancement Settings
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = DarkBorderGlass
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Slider 1: Hiss & Hum Reduction
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("High-Frequency Hiss Suppression", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("${hissReduction.toInt()}%", fontWeight = FontWeight.Bold, color = ElectricCyan)
                            }
                            Slider(
                                value = hissReduction,
                                onValueChange = { hissReduction = it },
                                valueRange = 20f..100f
                            )
                            Text("Reduces white noise, continuous fan hum, and electrical whine", style = MaterialTheme.typography.labelSmall, color = DarkTextSecondary)
                        }

                        // Slider 2: Vocal Presence Boost
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Vocal Presence Boost", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("+${String.format("%.1f", vocalBoostDb)} dB", fontWeight = FontWeight.Bold, color = NeonEmerald)
                            }
                            Slider(
                                value = vocalBoostDb,
                                onValueChange = { vocalBoostDb = it },
                                valueRange = 0f..8f
                            )
                            Text("Amplifies speech formant range for crisp podcast & dialogue clarity", style = MaterialTheme.typography.labelSmall, color = DarkTextSecondary)
                        }

                        // Slider 3: Noise Gate Floor
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Noise Gate Floor", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                Text("${(noiseGateFloor * 100).toInt()}%", fontWeight = FontWeight.Bold, color = IndigoViolet)
                            }
                            Slider(
                                value = noiseGateFloor,
                                onValueChange = { noiseGateFloor = it },
                                valueRange = 0.01f..0.12f
                            )
                            Text("Silences room ambiance during pauses between spoken words", style = MaterialTheme.typography.labelSmall, color = DarkTextSecondary)
                        }
                    }
                }

                // Action Button
                Button(
                    onClick = {
                        viewModel.denoiseAudio(
                            hissReductionPercent = hissReduction.toInt(),
                            vocalBoostDb = vocalBoostDb,
                            noiseGateFloor = noiseGateFloor
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("start_denoise_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = Color.Black
                    )
                ) {
                    Icon(Icons.Default.AutoFixHigh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Apply Studio Denoise & Clean-Up", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
