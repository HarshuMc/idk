package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioExtractScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Audio Extractor", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = com.example.ui.theme.DarkBg
                )
            )
        },
        containerColor = com.example.ui.theme.DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                EmptyMediaSelector(
                    title = "Select Video to Extract Audio",
                    subtitle = "Rip audio directly from any video into high-quality M4A/AAC.",
                    buttonText = "Choose Video",
                    icon = Icons.Default.Headphones,
                    onSelect = {
                        pickVideoLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                )
            } else {
                MediaFileCard(
                    mediaInfo = selectedMedia!!,
                    onChangeFile = {
                        pickVideoLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                )

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Lossless Direct Stream Extraction",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Extracts the original audio track straight from the video container in under a second. No re-encoding loss, pristine studio fidelity, and ultra-fast saving.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = { viewModel.extractAudio() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("extract_audio_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.FileDownload, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Extract Audio Now",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
