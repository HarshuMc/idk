package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AudioTargetFormat
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioFormatChangerScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var selectedFormat by remember { mutableStateOf(AudioTargetFormat.MP3) }
    var targetBitrateKbps by remember { mutableIntStateOf(192) }

    val pickAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.onMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Audio Format Changer", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = com.example.ui.theme.DarkBg)
            )
        },
        containerColor = com.example.ui.theme.DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                EmptyMediaSelector(
                    title = "Select Audio File to Convert",
                    subtitle = "Convert between MP3, AAC, M4A, WAV, and OGG formats with custom bitrates.",
                    buttonText = "Choose Audio",
                    icon = Icons.Default.Transform,
                    onSelect = { pickAudioLauncher.launch("audio/*") }
                )
            } else {
                MediaFileCard(
                    mediaInfo = selectedMedia!!,
                    onChangeFile = { pickAudioLauncher.launch("audio/*") }
                )

                // Target Format
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Target Audio Format", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(10.dp))
                        AudioTargetFormat.values().forEach { fmt ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedFormat == fmt,
                                    onClick = { selectedFormat = fmt }
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(text = fmt.displayName, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }

                // Bitrate
                if (selectedFormat != AudioTargetFormat.WAV) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Target Bitrate", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(96, 128, 192, 256, 320).forEach { br ->
                                    FilterChip(
                                        selected = targetBitrateKbps == br,
                                        onClick = { targetBitrateKbps = br },
                                        label = { Text("${br}k") },
                                        modifier = Modifier.weight(1f)
                                    )
                                }
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        viewModel.convertAudioFormat(
                            targetFormat = selectedFormat,
                            targetBitrateKbps = targetBitrateKbps
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("convert_audio_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Transform, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Convert to ${selectedFormat.name}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
