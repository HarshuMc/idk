package com.example.ui.screens

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BgRemoverMode
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

enum class BackdropChoice(val label: String, val colorInt: Int?, val isPortraitBlur: Boolean) {
    TRANSPARENT("Transparent", null, false),
    STUDIO_WHITE("Studio White", android.graphics.Color.WHITE, false),
    OBSIDIAN_DARK("Obsidian Dark", android.graphics.Color.rgb(15, 20, 31), false),
    NEON_VIOLET("Cyber Violet", android.graphics.Color.rgb(139, 92, 246), false),
    PORTRAIT_BLUR("DSLR Blur", null, true)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BgRemoverScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val currentBitmap by viewModel.bgRemoverWorkingBmp.collectAsState()
    val originalBitmap by viewModel.bgRemoverOriginalBmp.collectAsState()
    val canUndo by viewModel.bgCanUndo.collectAsState()
    val canRedo by viewModel.bgCanRedo.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var activeMode by remember { mutableStateOf(BgRemoverMode.AUTO_AI) }
    var brushRadius by remember { mutableFloatStateOf(32f) }
    var chromaTolerance by remember { mutableFloatStateOf(0.35f) }
    var selectedChromaColor by remember { mutableIntStateOf(android.graphics.Color.GREEN) }
    var magicTolerance by remember { mutableFloatStateOf(0.25f) }
    var selectedBackdrop by remember { mutableStateOf(BackdropChoice.TRANSPARENT) }
    var isEyedropperActive by remember { mutableStateOf(false) }

    // Live brush touch indicator
    var touchPosition by remember { mutableStateOf<Offset?>(null) }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onBgRemoverMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Background Remover", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text(
                            text = "AI Cutout • Chroma • Magic Wand",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextMuted
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.undoBg() },
                        enabled = canUndo,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (canUndo) NeonCyan else DarkTextMuted)
                    }
                    IconButton(
                        onClick = { viewModel.redoBg() },
                        enabled = canRedo,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo", tint = if (canRedo) NeonCyan else DarkTextMuted)
                    }
                    if (currentBitmap != null) {
                        IconButton(
                            onClick = { viewModel.clearBgRemover() },
                            modifier = Modifier.testTag("clear_bg_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Change Photo", tint = DarkTextSecondary)
                        }
                        IconButton(
                            onClick = {
                                viewModel.saveBgRemovedBitmap(
                                    selectedBackdrop.colorInt,
                                    selectedBackdrop.isPortraitBlur
                                )
                            },
                            modifier = Modifier.testTag("save_bg_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = NeonCyan)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (currentBitmap == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyMediaSelector(
                        title = "Select Photo for Background Removal",
                        subtitle = "High-precision AI subject isolation, Chroma key eyedropper, Magic Wand & Healing Repair.",
                        buttonText = "Choose Photo",
                        icon = Icons.Default.AutoFixHigh,
                        onSelect = {
                            pickImageLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                }
            } else {
                val bmp = currentBitmap!!

                // Interactive Canvas Area with Checkerboard / Backdrop Preview
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF090D16))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(activeMode, brushRadius, magicTolerance, isEyedropperActive) {
                                if (isEyedropperActive) {
                                    detectTapGestures { offset ->
                                        val bw = bmp.width.toFloat()
                                        val bh = bmp.height.toFloat()
                                        val scale = minOf(size.width / bw, size.height / bh)
                                        val left = (size.width - bw * scale) / 2f
                                        val top = (size.height - bh * scale) / 2f

                                        val imgX = ((offset.x - left) / scale).toInt().coerceIn(0, bmp.width - 1)
                                        val imgY = ((offset.y - top) / scale).toInt().coerceIn(0, bmp.height - 1)
                                        selectedChromaColor = bmp.getPixel(imgX, imgY)
                                        isEyedropperActive = false
                                    }
                                } else if (activeMode == BgRemoverMode.MAGIC_WAND) {
                                    detectTapGestures { offset ->
                                        val bw = bmp.width.toFloat()
                                        val bh = bmp.height.toFloat()
                                        val scale = minOf(size.width / bw, size.height / bh)
                                        val left = (size.width - bw * scale) / 2f
                                        val top = (size.height - bh * scale) / 2f

                                        val imgX = ((offset.x - left) / scale).toInt().coerceIn(0, bmp.width - 1)
                                        val imgY = ((offset.y - top) / scale).toInt().coerceIn(0, bmp.height - 1)
                                        viewModel.applyMagicWand(imgX, imgY, magicTolerance)
                                    }
                                } else if (activeMode == BgRemoverMode.MANUAL_BRUSH || activeMode == BgRemoverMode.REPAIR) {
                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            touchPosition = offset
                                        },
                                        onDragEnd = {
                                            touchPosition = null
                                            viewModel.commitBgBrush()
                                        },
                                        onDragCancel = {
                                            touchPosition = null
                                            viewModel.commitBgBrush()
                                        }
                                    ) { change, _ ->
                                        change.consume()
                                        touchPosition = change.position
                                        val bw = bmp.width.toFloat()
                                        val bh = bmp.height.toFloat()
                                        val scale = minOf(size.width / bw, size.height / bh)
                                        val left = (size.width - bw * scale) / 2f
                                        val top = (size.height - bh * scale) / 2f

                                        val imgX = ((change.position.x - left) / scale).coerceIn(0f, bmp.width.toFloat())
                                        val imgY = ((change.position.y - top) / scale).coerceIn(0f, bmp.height.toFloat())
                                        val isRepair = (activeMode == BgRemoverMode.REPAIR)
                                        viewModel.applyBgBrush(imgX, imgY, brushRadius / scale, isRepair)
                                    }
                                }
                            }
                    ) {
                        // 1. Draw Checkerboard or selected backdrop
                        when (selectedBackdrop) {
                            BackdropChoice.TRANSPARENT -> {
                                val checkSize = 22f
                                val cols = (size.width / checkSize).toInt() + 1
                                val rows = (size.height / checkSize).toInt() + 1
                                for (r in 0 until rows) {
                                    for (c in 0 until cols) {
                                        val col = if ((r + c) % 2 == 0) Color(0xFF1B2333) else Color(0xFF111723)
                                        drawRect(
                                            color = col,
                                            topLeft = Offset(c * checkSize, r * checkSize),
                                            size = Size(checkSize, checkSize)
                                        )
                                    }
                                }
                            }
                            BackdropChoice.STUDIO_WHITE -> {
                                drawRect(color = Color.White)
                            }
                            BackdropChoice.OBSIDIAN_DARK -> {
                                drawRect(color = Color(0xFF0F141F))
                            }
                            BackdropChoice.NEON_VIOLET -> {
                                drawRect(
                                    brush = Brush.radialGradient(
                                        colors = listOf(Color(0xFF8B5CF6), Color(0xFF080B11)),
                                        center = Offset(size.width / 2f, size.height / 2f),
                                        radius = size.width * 0.8f
                                    )
                                )
                            }
                            BackdropChoice.PORTRAIT_BLUR -> {
                                drawRect(color = Color(0xFF161F30))
                            }
                        }

                        // 2. Draw working cutout
                        val bw = bmp.width.toFloat()
                        val bh = bmp.height.toFloat()
                        val scale = minOf(size.width / bw, size.height / bh)
                        val w = (bw * scale).toInt()
                        val h = (bh * scale).toInt()
                        val left = ((size.width - w) / 2f).toInt()
                        val top = ((size.height - h) / 2f).toInt()

                        drawImage(
                            image = bmp.asImageBitmap(),
                            dstOffset = IntOffset(left, top),
                            dstSize = IntSize(w, h)
                        )

                        // 3. Draw live touch indicator ring when brushing
                        touchPosition?.let { pos ->
                            if (activeMode == BgRemoverMode.MANUAL_BRUSH || activeMode == BgRemoverMode.REPAIR) {
                                drawCircle(
                                    color = if (activeMode == BgRemoverMode.MANUAL_BRUSH) Color(0xFFFF4D4D) else NeonCyan,
                                    radius = brushRadius,
                                    center = pos,
                                    style = Stroke(width = 2.5f)
                                )
                            }
                        }
                    }

                    // Eyedropper floating badge
                    if (isEyedropperActive) {
                        Surface(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .padding(top = 12.dp),
                            shape = RoundedCornerShape(20.dp),
                            color = NeonCyan,
                            shadowElevation = 8.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Colorize, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Tap anywhere on image to pick color", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }

                // Controls Bottom Panel
                Surface(
                    tonalElevation = 14.dp,
                    color = DarkSurface1,
                    border = BorderStroke(1.dp, DarkBorderGlass)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(14.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        // Backdrop selector row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Backdrop:", style = MaterialTheme.typography.labelMedium, color = DarkTextSecondary)
                            Row(
                                modifier = Modifier.horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                BackdropChoice.values().forEach { choice ->
                                    val isChosen = selectedBackdrop == choice
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isChosen) NeonCyan.copy(alpha = 0.2f) else DarkSurface2)
                                            .border(1.dp, if (isChosen) NeonCyan else DarkBorderGlass, RoundedCornerShape(8.dp))
                                            .clickable { selectedBackdrop = choice }
                                            .padding(horizontal = 10.dp, vertical = 5.dp)
                                    ) {
                                        Text(
                                            choice.label,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = if (isChosen) NeonCyan else DarkTextPrimary
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Tool Mode Tabs
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            BgRemoverMode.values().forEach { mode ->
                                val isSelected = activeMode == mode
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) NeonCyan else DarkSurface2)
                                        .border(1.dp, if (isSelected) NeonCyan else DarkBorderGlass, RoundedCornerShape(12.dp))
                                        .clickable {
                                            activeMode = mode
                                            isEyedropperActive = false
                                        }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text(
                                        text = mode.displayName,
                                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                        color = if (isSelected) Color.Black else DarkTextPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Dynamic Tool Settings
                        when (activeMode) {
                            BgRemoverMode.AUTO_AI -> {
                                Button(
                                    onClick = { viewModel.applyBgAuto() },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("apply_auto_ai_button"),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonCyan,
                                        contentColor = Color.Black
                                    )
                                ) {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Isolate Subject with Auto AI", fontWeight = FontWeight.Bold)
                                }
                            }
                            BgRemoverMode.CHROMA_KEY -> {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("Key Color:", style = MaterialTheme.typography.bodyMedium)
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            // Preset swatches
                                            listOf(
                                                Pair(android.graphics.Color.GREEN, Color(0xFF00E676)),
                                                Pair(android.graphics.Color.BLUE, Color(0xFF2979FF)),
                                                Pair(android.graphics.Color.WHITE, Color.White),
                                                Pair(android.graphics.Color.BLACK, Color.Black)
                                            ).forEach { (cInt, cCompose) ->
                                                Box(
                                                    modifier = Modifier
                                                        .size(26.dp)
                                                        .clip(CircleShape)
                                                        .background(cCompose)
                                                        .border(
                                                            width = if (selectedChromaColor == cInt) 2.5.dp else 1.dp,
                                                            color = if (selectedChromaColor == cInt) NeonCyan else DarkBorderGlass,
                                                            shape = CircleShape
                                                        )
                                                        .clickable {
                                                            selectedChromaColor = cInt
                                                            isEyedropperActive = false
                                                        }
                                                )
                                            }

                                            // Eyedropper Button
                                            FilledTonalIconButton(
                                                onClick = { isEyedropperActive = !isEyedropperActive },
                                                colors = IconButtonDefaults.filledTonalIconButtonColors(
                                                    containerColor = if (isEyedropperActive) NeonCyan else DarkSurface2,
                                                    contentColor = if (isEyedropperActive) Color.Black else NeonCyan
                                                ),
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Icon(Icons.Default.Colorize, contentDescription = "Pick color", modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Tolerance", style = MaterialTheme.typography.labelSmall, color = DarkTextSecondary)
                                        Text("${(chromaTolerance * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = NeonCyan)
                                    }
                                    Slider(
                                        value = chromaTolerance,
                                        onValueChange = { chromaTolerance = it },
                                        valueRange = 0.1f..0.7f
                                    )
                                    Button(
                                        onClick = { viewModel.applyBgChroma(selectedChromaColor, chromaTolerance) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(44.dp),
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = Color.Black)
                                    ) {
                                        Icon(Icons.Default.ContentCut, contentDescription = null, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Cut Out Chroma Color", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            BgRemoverMode.MAGIC_WAND -> {
                                Column {
                                    Text(
                                        "Tap on any background area on the photo to instantly flood-erase all contiguous matching colors.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextSecondary
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("Sensitivity", style = MaterialTheme.typography.labelSmall, color = DarkTextSecondary)
                                        Text("${(magicTolerance * 100).toInt()}%", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = NeonCyan)
                                    }
                                    Slider(
                                        value = magicTolerance,
                                        onValueChange = { magicTolerance = it },
                                        valueRange = 0.05f..0.6f
                                    )
                                }
                            }
                            BgRemoverMode.MANUAL_BRUSH, BgRemoverMode.REPAIR -> {
                                Column {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            if (activeMode == BgRemoverMode.MANUAL_BRUSH) "Precision Brush (Erase)" else "Repair Tool (Restore)",
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text("${brushRadius.toInt()}px", fontWeight = FontWeight.Bold, color = NeonCyan)
                                    }
                                    Slider(
                                        value = brushRadius,
                                        onValueChange = { brushRadius = it },
                                        valueRange = 10f..80f
                                    )
                                    Text(
                                        text = if (activeMode == BgRemoverMode.MANUAL_BRUSH) "Drag across photo to erase stubborn background patches." else "Drag across transparent areas to heal and restore original pixels.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DarkTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}

