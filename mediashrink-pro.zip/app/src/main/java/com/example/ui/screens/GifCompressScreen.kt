package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GifCompressScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var frameSkipStep by remember { mutableIntStateOf(2) } // 2 = keep every 2nd frame
    var scaleFactor by remember { mutableFloatStateOf(0.75f) }
    var maxColors by remember { mutableIntStateOf(128) }

    val pickGifLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.onMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("GIF Optimizer", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = com.example.ui.theme.DarkBg
                )
            )
        },
        containerColor = com.example.ui.theme.DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                EmptyMediaSelector(
                    title = "Select GIF to Optimize",
                    subtitle = "Reduce frame rate, scale dimensions and compress colors.",
                    buttonText = "Choose GIF",
                    icon = Icons.Default.Animation,
                    onSelect = {
                        pickGifLauncher.launch("image/gif")
                    }
                )
            } else {
                MediaFileCard(
                    mediaInfo = selectedMedia!!,
                    onChangeFile = {
                        pickGifLauncher.launch("image/gif")
                    }
                )

                // Frame Rate Drop
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Frame Rate Optimization",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Dropping redundant frames significantly cuts file weight while keeping animation smooth.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                Pair(1, "Original FPS"),
                                Pair(2, "Half FPS (-50%)"),
                                Pair(3, "1/3 FPS (-66%)")
                            ).forEach { (step, label) ->
                                FilterChip(
                                    selected = frameSkipStep == step,
                                    onClick = { frameSkipStep = step },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // Dimension Scale
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Dimension Scale",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "${(scaleFactor * 100).toInt()}%",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = scaleFactor,
                            onValueChange = { scaleFactor = it },
                            valueRange = 0.4f..1.0f,
                            steps = 5,
                            modifier = Modifier.testTag("gif_scale_slider")
                        )
                    }
                }

                // Palette Reduction
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Color Palette Size",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                Pair(64, "64 Colors (Mini)"),
                                Pair(128, "128 Colors (Opt)"),
                                Pair(256, "256 Colors (Full)")
                            ).forEach { (colors, label) ->
                                FilterChip(
                                    selected = maxColors == colors,
                                    onClick = { maxColors = colors },
                                    label = { Text(label) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Button(
                    onClick = {
                        viewModel.compressGif(
                            frameSkipStep = frameSkipStep,
                            scaleFactor = scaleFactor,
                            maxColors = maxColors
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("compress_gif_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Animation, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Optimize GIF",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
