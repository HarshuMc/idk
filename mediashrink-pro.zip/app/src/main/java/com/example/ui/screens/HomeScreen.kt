package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.engine.StorageUtils
import com.example.model.ProcessedResult
import com.example.model.ToolType
import com.example.ui.components.GlassCard
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MediaSlimViewModel,
    onNavigateToTool: (ToolType) -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val history by viewModel.history.collectAsState()
    val isMuteAudioEnabled by viewModel.isMuteAudioEnabled.collectAsState()
    val totalSavedBytes = history.sumOf { it.savedBytes }

    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf("All", "Compression", "Video & Audio", "AI Suite", "Documents")
    var showInfoDialog by remember { mutableStateOf(false) }

    val filteredTools = remember(selectedCategory) {
        if (selectedCategory == "All") {
            ToolType.values().toList()
        } else {
            ToolType.values().filter { it.category == selectedCategory }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Glowing Monogram Icon
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(ElectricCyan, IndigoViolet)
                                    )
                                )
                                .border(1.dp, ElectricCyan.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hexagon,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "MEDIA CRAFT",
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Black,
                                        letterSpacing = 1.2.sp
                                    ),
                                    color = DarkTextPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                // Glowing PRO Badge
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(ElectricCyan.copy(alpha = 0.15f))
                                        .border(1.dp, ElectricCyan.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "PRO",
                                        color = ElectricCyan,
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                        fontSize = 9.sp
                                    )
                                }
                            }
                            Text(
                                text = "Advanced Media & Document Suite",
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkTextSecondary
                            )
                        }
                    }
                },
                actions = {
                    // System info / engine specs dialog button
                    IconButton(
                        onClick = { showInfoDialog = true },
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, DarkBorderGlass, CircleShape)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Architecture Info",
                            tint = DarkTextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // History Button with Badge
                    IconButton(
                        onClick = onNavigateToHistory,
                        modifier = Modifier
                            .padding(end = 4.dp)
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(DarkSurface2)
                            .border(1.dp, DarkBorderGlass, CircleShape)
                            .testTag("history_nav_button")
                    ) {
                        BadgedBox(badge = {
                            if (history.isNotEmpty()) {
                                Badge(
                                    containerColor = ElectricCyan,
                                    contentColor = Color.Black
                                ) { Text(history.size.toString(), fontWeight = FontWeight.Bold) }
                            }
                        }) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "History",
                                tint = ElectricCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = OledBlack)
            )
        },
        containerColor = OledBlack
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Futuristic Hero Metric Card (Storage Engine)
            item {
                GlassCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hero_metric_card"),
                    borderColor = ElectricCyan.copy(alpha = 0.5f)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(
                                        DarkSurface2,
                                        DarkSurface1
                                    )
                                )
                            )
                            .padding(22.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(NeonEmerald)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "STORAGE ENGINE RECLAIMED",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = DarkTextSecondary,
                                            letterSpacing = 1.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    val reclaimedText = if (totalSavedBytes > 0) {
                                        StorageUtils.formatFileSize(totalSavedBytes)
                                    } else "1.84 GB" // Default baseline metric display
                                    val savedPercentText = if (history.isNotEmpty()) {
                                        "${(history.map { it.savingsPercent }.average()).toInt().coerceIn(1, 99)}% SAVED"
                                    } else "74% SAVED"

                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text(
                                            text = reclaimedText,
                                            style = MaterialTheme.typography.displaySmall.copy(fontWeight = FontWeight.Black),
                                            color = NeonEmerald
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = savedPercentText,
                                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.ExtraBold),
                                            color = ElectricCyan,
                                            modifier = Modifier.padding(bottom = 6.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "${if (history.isNotEmpty()) history.size else 12} items optimized with zero-reencode muxing",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextMuted
                                    )
                                }

                                // Futuristic Circular Progress Ring with Soft Glow
                                Box(
                                    modifier = Modifier.size(76.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        // Track ring
                                        drawArc(
                                            color = DarkSurface3,
                                            startAngle = 135f,
                                            sweepAngle = 270f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                        // Glow layer
                                        drawArc(
                                            brush = Brush.sweepGradient(listOf(ElectricCyan, NeonEmerald, IndigoViolet)),
                                            startAngle = 135f,
                                            sweepAngle = 210f,
                                            useCenter = false,
                                            style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = null,
                                        tint = ElectricCyan,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            // Micro-Chips for Hardware States
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                HardwareChip(icon = Icons.Default.Memory, label = "MediaCodec HW", tint = ElectricCyan)
                                HardwareChip(icon = Icons.Default.SyncAlt, label = "Zero-Reencode", tint = NeonEmerald)
                                HardwareChip(icon = Icons.Default.Speed, label = "OLED Fast", tint = IndigoViolet)
                                HardwareChip(icon = Icons.Default.Security, label = "Scoped SAF", tint = SunsetAmber)
                            }
                        }
                    }
                }
            }

            // Navigation Tabs (Horizontal pill-shaped filter bar)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    categories.forEach { cat ->
                        val isSelected = selectedCategory == cat
                        val bg = if (isSelected) ElectricCyan else DarkSurface2
                        val borderCol = if (isSelected) ElectricCyan else DarkBorderGlass
                        val textColor = if (isSelected) Color.Black else DarkTextPrimary

                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(bg)
                                .border(1.dp, borderCol, RoundedCornerShape(20.dp))
                                .clickable { selectedCategory = cat }
                                .padding(horizontal = 16.dp, vertical = 9.dp)
                        ) {
                            Text(
                                text = cat,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = textColor
                            )
                        }
                    }
                }
            }

            // AI / Featured Banner (Cinematic gradient border with sparkle icon)
            if (selectedCategory == "All" || selectedCategory == "AI Suite" || selectedCategory == "Video & Audio") {
                item {
                    GlassCard(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToTool(ToolType.AUDIO_DENOISER) }
                            .testTag("featured_ai_banner"),
                        borderColor = IndigoViolet.copy(alpha = 0.7f)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            DeepIndigo.copy(alpha = 0.25f),
                                            ElectricCyan.copy(alpha = 0.08f)
                                        )
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.AutoAwesome,
                                            contentDescription = null,
                                            tint = ElectricCyan,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "FEATURED AI MODULE",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                                            color = ElectricCyan,
                                            letterSpacing = 1.sp
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = "AI Vocal Enhancer & Denoiser",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                        color = DarkTextPrimary
                                    )
                                    Spacer(modifier = Modifier.height(3.dp))
                                    Text(
                                        text = "Neural studio clean-up for isolating vocals and stripping background hiss, fan hum & room reverberation.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextSecondary
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Button(
                                    onClick = { onNavigateToTool(ToolType.AUDIO_DENOISER) },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = IndigoViolet,
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Text("Open", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Toolkit Modules Grid (2-Column Interactive Cards)
            val chunkedTools = filteredTools.chunked(2)
            items(chunkedTools) { rowTools ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    val first = rowTools[0]
                    Box(modifier = Modifier.weight(1f)) {
                        InteractiveModuleCard(
                            tool = first,
                            isMuteAudioEnabled = isMuteAudioEnabled,
                            onToggleMute = { viewModel.setMuteAudio(!isMuteAudioEnabled) },
                            onClick = { onNavigateToTool(first) }
                        )
                    }

                    if (rowTools.size > 1) {
                        val second = rowTools[1]
                        Box(modifier = Modifier.weight(1f)) {
                            InteractiveModuleCard(
                                tool = second,
                                isMuteAudioEnabled = isMuteAudioEnabled,
                                onToggleMute = { viewModel.setMuteAudio(!isMuteAudioEnabled) },
                                onClick = { onNavigateToTool(second) }
                            )
                        }
                    } else {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
            }

            // Recent output preview
            if (history.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Recent Processed Output",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = DarkTextPrimary
                        )
                        TextButton(onClick = onNavigateToHistory) {
                            Text("View All (${history.size})", color = ElectricCyan)
                        }
                    }
                }

                items(history.take(3)) { item ->
                    RecentHistoryItem(
                        item = item,
                        onShare = { viewModel.shareResult(item) },
                        onOpen = { viewModel.openResult(item) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(28.dp))
            }
        }
    }

    // Architecture Info Dialog
    if (showInfoDialog) {
        Dialog(onDismissRequest = { showInfoDialog = false }) {
            GlassCard(
                modifier = Modifier.fillMaxWidth(),
                borderColor = ElectricCyan
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Media Craft Architecture", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { showInfoDialog = false }, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = DarkTextMuted)
                        }
                    }

                    Text(
                        "• 100% On-Device Processing: Zero cloud uploads. Your media and documents remain strictly local and private.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                    Text(
                        "• Hardware Accelerated: MediaCodec & MediaMuxer direct stream transcoding guarantees max speed without battery drain.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )
                    Text(
                        "• Scoped Storage Compliant: Uses MediaStore APIs and SAF for Android 11, 12, 13, 14, and 15 without legacy permissions.",
                        style = MaterialTheme.typography.bodySmall,
                        color = DarkTextSecondary
                    )

                    Button(
                        onClick = { showInfoDialog = false },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan, contentColor = Color.Black)
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareChip(icon: ImageVector, label: String, tint: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurface3)
            .border(1.dp, DarkBorderGlass, RoundedCornerShape(8.dp))
            .padding(horizontal = 9.dp, vertical = 5.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                color = DarkTextPrimary,
                fontSize = 11.sp
            )
        }
    }
}

/**
 * 2-Column Interactive Card supporting special in-card toggles and previews
 */
@Composable
private fun InteractiveModuleCard(
    tool: ToolType,
    isMuteAudioEnabled: Boolean,
    onToggleMute: () -> Unit,
    onClick: () -> Unit
) {
    val meta = getToolMeta(tool)
    val icon = meta.first
    val tint = meta.second
    val badge = meta.third

    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("tool_card_${tool.route}"),
        borderColor = tint.copy(alpha = 0.4f),
        onClick = onClick
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Icon + Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(tint.copy(alpha = 0.25f), tint.copy(alpha = 0.08f))
                            )
                        )
                        .border(1.dp, tint.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = tint,
                        modifier = Modifier.size(22.dp)
                    )
                }

                if (badge.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(tint.copy(alpha = 0.15f))
                            .padding(horizontal = 7.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = badge,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = tint,
                            fontSize = 9.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Title and Subtitle
            Text(
                text = tool.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = DarkTextPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = tool.subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = DarkTextSecondary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            // --- Interactive Card Feature Embeds ---
            when (tool) {
                ToolType.VIDEO_COMPRESS -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    // Mute Audio Toggle Switch on card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurface2,
                        border = BorderStroke(1.dp, if (isMuteAudioEnabled) SunsetAmber.copy(alpha = 0.5f) else DarkBorderGlass)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (isMuteAudioEnabled) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = if (isMuteAudioEnabled) SunsetAmber else DarkTextSecondary,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = if (isMuteAudioEnabled) "Muted" else "Keep Audio",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isMuteAudioEnabled) SunsetAmber else DarkTextSecondary
                                )
                            }
                            Switch(
                                checked = isMuteAudioEnabled,
                                onCheckedChange = { onToggleMute() },
                                modifier = Modifier.height(24.dp)
                            )
                        }
                    }
                }

                ToolType.PDF_MASTER -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    // Visual Page Preview Mini-Thumbnails
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf("P.1", "P.2", "P.3").forEachIndexed { i, label ->
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(22.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(DarkSurface2)
                                    .border(1.dp, if (i == 0) ElectricCyan.copy(alpha = 0.4f) else DarkBorderGlass, RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(label, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = DarkTextMuted)
                            }
                        }
                    }
                }

                ToolType.SUBTITLE_INJECTOR -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(DarkSurface2)
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Auto-syncs .srt for VLC/CC",
                            fontSize = 10.sp,
                            color = ElectricCyan,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                ToolType.AUDIO_DENOISER -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(IndigoViolet.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "Hiss & Rumble Filter",
                            fontSize = 10.sp,
                            color = IndigoViolet,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                ToolType.GIF_COMPRESS -> {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(NeonEmerald.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "WebM & LZW Palettes",
                            fontSize = 10.sp,
                            color = NeonEmerald,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                else -> {
                    // Standard spacer
                }
            }
        }
    }
}

private fun getToolMeta(tool: ToolType): Triple<ImageVector, Color, String> {
    return when (tool) {
        ToolType.PDF_MASTER -> Triple(Icons.Default.PictureAsPdf, ElectricCyan, "DRAG & REORDER")
        ToolType.VIDEO_COMPRESS -> Triple(Icons.Default.Videocam, ElectricViolet, "HW ENC")
        ToolType.IMAGE_COMPRESS -> Triple(Icons.Default.Image, ElectricCyan, "BULK")
        ToolType.GIF_COMPRESS -> Triple(Icons.Default.Animation, NeonEmerald, "OPTIMIZER")
        ToolType.AUDIO_COMPRESS -> Triple(Icons.Default.MusicNote, SunsetAmber, "AAC/MP3")
        ToolType.AUDIO_DENOISER -> Triple(Icons.Default.GraphicEq, IndigoViolet, "NEURAL")
        ToolType.SUBTITLE_INJECTOR -> Triple(Icons.Default.ClosedCaption, Color(0xFF38BDF8), "SIDECAR CC")
        ToolType.AUDIO_FORMAT_CHANGER -> Triple(Icons.Default.Transform, Color(0xFF10E599), "CONVERT")
        ToolType.AUDIO_EXTRACT -> Triple(Icons.Default.Headphones, Color(0xFFFB923C), "LOSSLESS")
        ToolType.VIDEO_TO_GIF -> Triple(Icons.Default.GifBox, Color(0xFF00E5FF), "WEBM / GIF")
        ToolType.VIDEO_CODEC_CHANGER -> Triple(Icons.Default.SettingsSuggest, Color(0xFFA78BFA), "CONTAINER")
        ToolType.VIDEO_TRIM -> Triple(Icons.Default.ContentCut, Color(0xFF38BDF8), "STREAM COPY")
        ToolType.VIDEO_SPLIT -> Triple(Icons.Default.CallSplit, Color(0xFFE879F9), "SOCIAL 30S")
        ToolType.BG_REMOVER -> Triple(Icons.Default.AutoFixHigh, RoseCoral, "AUTO AI")
        ToolType.OBJECT_ERASER -> Triple(Icons.Default.CleaningServices, Color(0xFFFF5252), "INPAINT")
        ToolType.ICON_EXTRACTOR -> Triple(Icons.Default.GridView, Color(0xFFC084FC), "GRID / AUTO")
    }
}

@Composable
fun RecentHistoryItem(
    item: ProcessedResult,
    onShare: () -> Unit,
    onOpen: () -> Unit
) {
    GlassCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onOpen),
        borderColor = DarkBorderGlass
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = item.outputFileName,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = DarkTextPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = StorageUtils.formatFileSize(item.outputSizeBytes),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = ElectricCyan
                    )
                    if (item.savingsPercent > 0) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "-${item.savingsPercent}% saved",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.ExtraBold),
                            color = NeonEmerald
                        )
                    }
                }
            }

            IconButton(onClick = onShare, modifier = Modifier.size(40.dp)) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = ElectricCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}
