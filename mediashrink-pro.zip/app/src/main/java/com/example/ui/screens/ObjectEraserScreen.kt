package com.example.ui.screens

import android.graphics.Bitmap
import android.graphics.Paint
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ObjectEraserScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val currentBitmap by viewModel.objectEraserWorkingBmp.collectAsState()
    val originalBitmap by viewModel.objectEraserOriginalBmp.collectAsState()
    val canUndo by viewModel.eraserCanUndo.collectAsState()
    val canRedo by viewModel.eraserCanRedo.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var brushRadius by remember { mutableFloatStateOf(35f) }
    var showOriginal by remember { mutableStateOf(false) }

    // Live brush touch indicator
    var touchPosition by remember { mutableStateOf<Offset?>(null) }

    // Mask bitmap where user paints red strokes
    var maskBitmap by remember(currentBitmap) {
        mutableStateOf<Bitmap?>(null)
    }

    LaunchedEffect(currentBitmap) {
        currentBitmap?.let {
            if (maskBitmap == null || maskBitmap?.width != it.width || maskBitmap?.height != it.height) {
                maskBitmap = Bitmap.createBitmap(it.width, it.height, Bitmap.Config.ARGB_8888)
            }
        }
    }

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onObjectEraserMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("AI Object Eraser", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Content-Aware Inpainting", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { viewModel.undoEraser() },
                        enabled = canUndo,
                        modifier = Modifier.testTag("undo_eraser_button")
                    ) {
                        Icon(Icons.Default.Undo, contentDescription = "Undo", tint = if (canUndo) NeonCyan else DarkTextMuted)
                    }
                    IconButton(
                        onClick = { viewModel.redoEraser() },
                        enabled = canRedo,
                        modifier = Modifier.testTag("redo_eraser_button")
                    ) {
                        Icon(Icons.Default.Redo, contentDescription = "Redo", tint = if (canRedo) NeonCyan else DarkTextMuted)
                    }
                    if (currentBitmap != null) {
                        IconButton(
                            onClick = { viewModel.clearObjectEraser() },
                            modifier = Modifier.testTag("clear_eraser_button")
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Change Photo", tint = DarkTextSecondary)
                        }
                        IconButton(
                            onClick = { viewModel.saveObjectErasedBitmap() },
                            modifier = Modifier.testTag("save_erased_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save", tint = NeonCyan)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (currentBitmap == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyMediaSelector(
                        title = "Select Photo to Erase Objects",
                        subtitle = "Brush over unwanted people, wires, text, watermarks, or photo blemishes with intelligent neural inpainting.",
                        buttonText = "Choose Photo",
                        icon = Icons.Default.CleaningServices,
                        onSelect = {
                            pickImageLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        }
                    )
                }
            } else {
                val bmp = if (showOriginal && originalBitmap != null) originalBitmap!! else currentBitmap!!
                val mask = maskBitmap

                // Interactive Painting Area
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(Color(0xFF090D16))
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(mask, brushRadius, showOriginal) {
                                if (mask != null && !showOriginal) {
                                    val maskCanvas = android.graphics.Canvas(mask)
                                    val paint = Paint().apply {
                                        color = android.graphics.Color.RED
                                        alpha = 180
                                        isAntiAlias = true
                                        strokeCap = Paint.Cap.ROUND
                                        strokeJoin = Paint.Join.ROUND
                                    }

                                    detectDragGestures(
                                        onDragStart = { offset ->
                                            touchPosition = offset
                                        },
                                        onDragEnd = {
                                            touchPosition = null
                                        },
                                        onDragCancel = {
                                            touchPosition = null
                                        }
                                    ) { change, _ ->
                                        change.consume()
                                        touchPosition = change.position
                                        val bw = bmp.width.toFloat()
                                        val bh = bmp.height.toFloat()
                                        val scale = minOf(size.width / bw, size.height / bh)
                                        val left = (size.width - bw * scale) / 2f
                                        val top = (size.height - bh * scale) / 2f

                                        val imgX = ((change.position.x - left) / scale).coerceIn(0f, bmp.width.toFloat())
                                        val imgY = ((change.position.y - top) / scale).coerceIn(0f, bmp.height.toFloat())
                                        maskCanvas.drawCircle(imgX, imgY, brushRadius / scale, paint)
                                    }
                                }
                            }
                    ) {
                        val bw = bmp.width.toFloat()
                        val bh = bmp.height.toFloat()
                        val scale = minOf(size.width / bw, size.height / bh)
                        val w = (bw * scale).toInt()
                        val h = (bh * scale).toInt()
                        val left = ((size.width - w) / 2f).toInt()
                        val top = ((size.height - h) / 2f).toInt()

                        // 1. Draw base photo
                        drawImage(
                            image = bmp.asImageBitmap(),
                            dstOffset = IntOffset(left, top),
                            dstSize = IntSize(w, h)
                        )

                        // 2. Draw red inpainting mask
                        if (!showOriginal && mask != null) {
                            drawImage(
                                image = mask.asImageBitmap(),
                                dstOffset = IntOffset(left, top),
                                dstSize = IntSize(w, h)
                            )
                        }

                        // 3. Draw live touch indicator ring
                        touchPosition?.let { pos ->
                            if (!showOriginal) {
                                drawCircle(
                                    color = Color(0xFFFF3366),
                                    radius = brushRadius,
                                    center = pos,
                                    style = Stroke(width = 2.5f)
                                )
                            }
                        }
                    }

                    // Before/After Hold Button
                    FilledTonalButton(
                        onClick = { showOriginal = !showOriginal },
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = if (showOriginal) ElectricViolet else DarkSurface2,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.Compare, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (showOriginal) "Original" else "Compare", fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    }
                }

                // Controls Bottom Panel
                Surface(
                    tonalElevation = 14.dp,
                    color = DarkSurface1,
                    border = BorderStroke(1.dp, DarkBorderGlass)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Eraser Brush Size", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("${brushRadius.toInt()}px", fontWeight = FontWeight.Bold, color = NeonCyan)
                        }
                        Slider(
                            value = brushRadius,
                            onValueChange = { brushRadius = it },
                            valueRange = 15f..90f
                        )

                        Text(
                            text = "Paint in red over any unwanted object, person, or blemish.",
                            style = MaterialTheme.typography.labelSmall,
                            color = DarkTextSecondary
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    maskBitmap?.eraseColor(android.graphics.Color.TRANSPARENT)
                                },
                                modifier = Modifier.weight(1f).height(48.dp),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, DarkBorderGlass)
                            ) {
                                Icon(Icons.Default.Clear, contentDescription = null, tint = DarkTextSecondary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Clear Mask", color = DarkTextSecondary)
                            }

                            Button(
                                onClick = {
                                    maskBitmap?.let { mask ->
                                        viewModel.eraseObject(mask)
                                        mask.eraseColor(android.graphics.Color.TRANSPARENT)
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .height(48.dp)
                                    .testTag("apply_erase_object_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NeonCyan,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(Icons.Default.AutoFixHigh, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Erase Object", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}

