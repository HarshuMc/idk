package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.PdfPageModel
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfMasterScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val pdfPages by viewModel.pdfPages.collectAsState()
    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var qualityPercent by remember { mutableIntStateOf(80) }
    var selectedPageIndex by remember { mutableStateOf<Int?>(null) }

    val pickPdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadPdf(it) }
    }

    val pickMultiplePdfsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.mergePdfs(uris)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("PDF Master & Merger", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Visual Page Rearrangement • Compression", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(
                        onClick = { pickMultiplePdfsLauncher.launch(arrayOf("application/pdf")) },
                        modifier = Modifier.testTag("merge_pdfs_button")
                    ) {
                        Icon(Icons.Default.MergeType, contentDescription = "Merge Multiple PDFs", tint = ElectricCyan)
                    }
                    if (pdfPages.isNotEmpty()) {
                        IconButton(
                            onClick = { viewModel.exportPdf(qualityPercent) },
                            modifier = Modifier.testTag("export_pdf_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Save PDF", tint = NeonEmerald)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (pdfPages.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        EmptyMediaSelector(
                            title = "Select PDF Document",
                            subtitle = "Visually reorder pages, rotate, remove, compress file size, or merge multiple PDFs.",
                            buttonText = "Open PDF Document",
                            icon = Icons.Default.PictureAsPdf,
                            onSelect = {
                                pickPdfLauncher.launch(arrayOf("application/pdf"))
                            }
                        )

                        // Secondary Merge Action
                        OutlinedButton(
                            onClick = { pickMultiplePdfsLauncher.launch(arrayOf("application/pdf")) },
                            shape = RoundedCornerShape(14.dp),
                            border = BorderStroke(1.dp, IndigoViolet.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = IndigoViolet),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(Icons.Default.MergeType, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Merge 2 or More PDFs", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            } else {
                // Header info bar
                Surface(
                    color = DarkSurface1,
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, DarkBorderGlass)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = selectedMedia?.fileName ?: "Document.pdf",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = DarkTextPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${pdfPages.size} pages • Tap card to reorder or rotate",
                                style = MaterialTheme.typography.labelSmall,
                                color = DarkTextSecondary
                            )
                        }

                        Button(
                            onClick = { viewModel.exportPdf(qualityPercent) },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricCyan,
                                contentColor = Color.Black
                            ),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Icon(Icons.Default.FileDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }

                // Grid of Page Thumbnails (Interactive drag/reorder controls)
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier
                        .weight(1f)
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    itemsIndexed(pdfPages) { index, page ->
                        val isSelected = selectedPageIndex == index

                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .border(
                                    width = if (isSelected) 2.dp else 1.dp,
                                    color = if (isSelected) ElectricCyan else DarkBorderGlass,
                                    shape = RoundedCornerShape(20.dp)
                                )
                                .clickable { selectedPageIndex = if (isSelected) null else index },
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface1)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                // Thumbnail Image
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.White),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Image(
                                        bitmap = page.thumbnail.asImageBitmap(),
                                        contentDescription = "Page ${index + 1}",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )

                                    // Page Number Badge
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .padding(6.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color.Black.copy(alpha = 0.75f))
                                            .padding(horizontal = 8.dp, vertical = 3.dp)
                                    ) {
                                        Text(
                                            text = "P.${index + 1}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    if (page.rotationDegrees != 0) {
                                        Box(
                                            modifier = Modifier
                                                .align(Alignment.TopEnd)
                                                .padding(6.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(ElectricCyan.copy(alpha = 0.85f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "${page.rotationDegrees}°",
                                                color = Color.Black,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                // Reordering Actions Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Move Left / Up
                                    IconButton(
                                        onClick = { viewModel.movePdfPage(index, (index - 1).coerceAtLeast(0)) },
                                        enabled = index > 0,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ArrowBack,
                                            contentDescription = "Move earlier",
                                            tint = if (index > 0) ElectricCyan else DarkTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    // Rotate 90
                                    IconButton(
                                        onClick = { viewModel.rotatePdfPage(index) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.RotateRight,
                                            contentDescription = "Rotate",
                                            tint = IndigoViolet,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // Delete page
                                    IconButton(
                                        onClick = { viewModel.deletePdfPage(index) },
                                        enabled = pdfPages.size > 1,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.DeleteOutline,
                                            contentDescription = "Delete Page",
                                            tint = if (pdfPages.size > 1) RoseCoral else DarkTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    // Move Right / Down
                                    IconButton(
                                        onClick = { viewModel.movePdfPage(index, (index + 1).coerceAtMost(pdfPages.size - 1)) },
                                        enabled = index < pdfPages.size - 1,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.ArrowForward,
                                            contentDescription = "Move later",
                                            tint = if (index < pdfPages.size - 1) ElectricCyan else DarkTextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Bottom Compression & Export Controls
                Surface(
                    color = DarkSurface1,
                    tonalElevation = 14.dp,
                    border = BorderStroke(1.dp, DarkBorderGlass)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("PDF Optimization Level", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            Text("$qualityPercent% Quality", fontWeight = FontWeight.Bold, color = ElectricCyan)
                        }

                        Slider(
                            value = qualityPercent.toFloat(),
                            onValueChange = { qualityPercent = it.toInt() },
                            valueRange = 40f..100f
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("High Compression (Smallest file)", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                            Text("Maximum Crispness", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                        }
                    }
                }
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
