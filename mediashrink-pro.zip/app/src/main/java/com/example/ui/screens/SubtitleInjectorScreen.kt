package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.SubtitleCue
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubtitleInjectorScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val cues by viewModel.subtitleCues.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var offsetMs by remember { mutableLongStateOf(0L) }
    var showAddDialog by remember { mutableStateOf(false) }
    var newCueText by remember { mutableStateOf("") }
    var newCueStart by remember { mutableStateOf("00:00:01") }
    var newCueEnd by remember { mutableStateOf("00:00:05") }

    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.loadVideoForSubtitles(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Sidecar Subtitle Injector", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("External Synced CC for VLC & Media Players", style = MaterialTheme.typography.labelSmall, color = DarkTextMuted)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    if (selectedMedia != null) {
                        IconButton(onClick = { showAddDialog = true }) {
                            Icon(Icons.Default.Add, contentDescription = "Add Cue", tint = ElectricCyan)
                        }
                        IconButton(
                            onClick = { viewModel.exportSidecarSubtitle(offsetMs) },
                            modifier = Modifier.testTag("export_subtitles_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = "Export Sidecar .srt", tint = NeonEmerald)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            if (selectedMedia == null) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    EmptyMediaSelector(
                        title = "Select Video to Add Subtitles",
                        subtitle = "Creates a synchronized standalone sidecar (.srt) subtitle track. Media players like VLC detect it automatically with the CC button.",
                        buttonText = "Choose Video",
                        icon = Icons.Default.ClosedCaption,
                        onSelect = { pickVideoLauncher.launch("video/*") }
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Spacer(modifier = Modifier.height(4.dp))
                        MediaFileCard(
                            mediaInfo = selectedMedia!!,
                            onRemove = { viewModel.clearSelection() }
                        )
                    }

                    // Drift / Sync Compensation Card
                    item {
                        GlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            borderColor = ElectricCyan.copy(alpha = 0.4f)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Audio/Video Sync Drift", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = "${if (offsetMs > 0) "+" else ""}${offsetMs}ms",
                                        fontWeight = FontWeight.Bold,
                                        color = if (offsetMs == 0L) ElectricCyan else SunsetAmber
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    FilledTonalButton(
                                        onClick = { offsetMs -= 250L },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("-250ms")
                                    }
                                    FilledTonalButton(
                                        onClick = { offsetMs = 0L },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("Reset")
                                    }
                                    FilledTonalButton(
                                        onClick = { offsetMs += 250L },
                                        modifier = Modifier.weight(1f),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("+250ms")
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Subtitle Cues (${cues.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showAddDialog = true }) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add Line", color = ElectricCyan)
                            }
                        }
                    }

                    itemsIndexed(cues) { index, cue ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, DarkBorderGlass),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface1)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(ElectricCyan.copy(alpha = 0.15f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                "#${cue.id}",
                                                color = ElectricCyan,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "${cue.formatSrtTimestamp(cue.startTimeMs)} ➔ ${cue.formatSrtTimestamp(cue.endTimeMs)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = DarkTextSecondary
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = cue.text,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                                        color = DarkTextPrimary
                                    )
                                }

                                IconButton(
                                    onClick = { viewModel.deleteSubtitleCue(index) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = RoseCoral, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }

                // Bottom Export Button
                Surface(
                    color = DarkSurface1,
                    border = BorderStroke(1.dp, DarkBorderGlass),
                    tonalElevation = 14.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Button(
                            onClick = { viewModel.exportSidecarSubtitle(offsetMs) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("export_sidecar_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ElectricCyan,
                                contentColor = Color.Black
                            )
                        ) {
                            Icon(Icons.Default.ClosedCaption, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Inject & Export Sidecar Subtitle (.srt)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add Subtitle Line", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = newCueText,
                        onValueChange = { newCueText = it },
                        label = { Text("Subtitle Dialogue") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = newCueStart,
                            onValueChange = { newCueStart = it },
                            label = { Text("Start (s)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = newCueEnd,
                            onValueChange = { newCueEnd = it },
                            label = { Text("End (s)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val sSec = newCueStart.toDoubleOrNull() ?: 1.0
                        val eSec = newCueEnd.toDoubleOrNull() ?: (sSec + 4.0)
                        viewModel.addSubtitleCue(
                            text = if (newCueText.isBlank()) "New subtitle line" else newCueText,
                            startMs = (sSec * 1000).toLong(),
                            endMs = (eSec * 1000).toLong()
                        )
                        showAddDialog = false
                        newCueText = ""
                    }
                ) {
                    Text("Add Cue")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
