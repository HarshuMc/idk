package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.StorageUtils
import com.example.model.VideoCompressionPreset
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoCompressScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val batchVideos by viewModel.selectedBatchVideos.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var compressionMode by remember { mutableStateOf("presets") } // "presets" or "target_size"
    var selectedPreset by remember { mutableStateOf(VideoCompressionPreset.MEDIUM) }
    var targetSizeMb by remember { mutableFloatStateOf(16f) }
    var customBitrateKbps by remember { mutableFloatStateOf(1200f) }
    var customScale by remember { mutableFloatStateOf(0.7f) }

    val pickMultipleVideosLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.onBatchVideosSelected(uris)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Video Compressor", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBg
                )
            )
        },
        containerColor = DarkBg
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                EmptyMediaSelector(
                    title = "Select Video(s) to Compress",
                    subtitle = "Hardware-accelerated H.264 transcoding with Target MB calculator.",
                    buttonText = "Choose Videos (Bulk enabled)",
                    icon = Icons.Default.VideoLibrary,
                    onSelect = {
                        pickMultipleVideosLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                )
            } else {
                MediaFileCard(
                    mediaInfo = selectedMedia!!,
                    onChangeFile = {
                        pickMultipleVideosLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                        )
                    }
                )

                if (batchVideos.size > 1) {
                    GlassCard(borderColor = ElectricViolet) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Layers,
                                contentDescription = null,
                                tint = ElectricViolet
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "${batchVideos.size} videos queued for batch hardware compression",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }

                // Mode Selector Tabs: Presets vs Target File Size
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (compressionMode == "presets") NeonCyan else DarkSurface2)
                            .border(1.dp, if (compressionMode == "presets") NeonCyan else DarkBorderGlass, RoundedCornerShape(12.dp))
                            .clickable { compressionMode = "presets" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Quality Presets",
                            fontWeight = FontWeight.Bold,
                            color = if (compressionMode == "presets") Color.Black else DarkTextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (compressionMode == "target_size") NeonCyan else DarkSurface2)
                            .border(1.dp, if (compressionMode == "target_size") NeonCyan else DarkBorderGlass, RoundedCornerShape(12.dp))
                            .clickable { compressionMode = "target_size" }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "Target Size (MB)",
                            fontWeight = FontWeight.Bold,
                            color = if (compressionMode == "target_size") Color.Black else DarkTextPrimary
                        )
                    }
                }

                if (compressionMode == "target_size") {
                    // Advanced Target File Size Calculator
                    GlassCard(borderColor = NeonCyan.copy(alpha = 0.5f)) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Target File Limit", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    text = "${targetSizeMb.toInt()} MB",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.ExtraBold),
                                    color = NeonCyan
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Auto-calculates the optimal bitrate & downscaling factor for your video duration.",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            // Quick preset pills
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    Pair(10f, "10 MB"),
                                    Pair(16f, "16 MB (Discord)"),
                                    Pair(25f, "25 MB (Email)"),
                                    Pair(50f, "50 MB (HD)")
                                ).forEach { (mb, label) ->
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (targetSizeMb == mb) NeonCyan.copy(alpha = 0.2f) else DarkSurface3)
                                            .border(1.dp, if (targetSizeMb == mb) NeonCyan else DarkBorderGlass, RoundedCornerShape(8.dp))
                                            .clickable { targetSizeMb = mb }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (targetSizeMb == mb) NeonCyan else DarkTextPrimary,
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Slider(
                                value = targetSizeMb,
                                onValueChange = { targetSizeMb = it },
                                valueRange = 5f..100f,
                                steps = 18
                            )
                        }
                    }
                } else {
                    // Presets
                    VideoCompressionPreset.values().forEach { preset ->
                        val isSelected = selectedPreset == preset
                        GlassCard(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPreset = preset }
                                .testTag("preset_${preset.name.lowercase()}"),
                            borderColor = if (isSelected) NeonCyan else DarkBorderGlass
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedPreset = preset },
                                    colors = RadioButtonDefaults.colors(selectedColor = NeonCyan)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = preset.displayName,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = preset.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextSecondary
                                    )
                                }
                            }
                        }
                    }
                }

                // Mute Audio Toggle Switch Card
                GlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    borderColor = if (viewModel.isMuteAudioEnabled.collectAsState().value) SunsetAmber else DarkBorderGlass
                ) {
                    val isMuteEnabled by viewModel.isMuteAudioEnabled.collectAsState()
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isMuteEnabled) SunsetAmber.copy(alpha = 0.2f) else DarkSurface2),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (isMuteEnabled) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = null,
                                    tint = if (isMuteEnabled) SunsetAmber else DarkTextPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Mute Audio Track",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = if (isMuteEnabled) "Strips audio completely (Smaller file size)" else "Preserves original video audio track",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = DarkTextSecondary
                                )
                            }
                        }

                        Switch(
                            checked = isMuteEnabled,
                            onCheckedChange = { viewModel.setMuteAudio(it) }
                        )
                    }
                }

                Button(
                    onClick = {
                        val durationSec = ((selectedMedia?.durationMs ?: 10000L) / 1000L).coerceAtLeast(1L)
                        if (compressionMode == "target_size") {
                            // Target size calculation: Bitrate = (TargetMB * 8192) / DurationSec
                            val calculatedBitrateKbps = ((targetSizeMb * 8192f) / durationSec.toFloat()).toInt().coerceIn(300, 3500)
                            val autoScale = if (calculatedBitrateKbps < 800) 0.5f else if (calculatedBitrateKbps < 1500) 0.7f else 1.0f
                            viewModel.compressVideos(
                                preset = VideoCompressionPreset.CUSTOM,
                                customBitrateKbps = calculatedBitrateKbps,
                                customScale = autoScale
                            )
                        } else {
                            viewModel.compressVideos(
                                preset = selectedPreset,
                                customBitrateKbps = customBitrateKbps.toInt(),
                                customScale = customScale
                            )
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("compress_video_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonCyan,
                        contentColor = Color.Black
                    )
                ) {
                    Icon(imageVector = Icons.Default.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (batchVideos.size > 1) "Compress All ${batchVideos.size} Videos" else "Hardware Compress Video",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
