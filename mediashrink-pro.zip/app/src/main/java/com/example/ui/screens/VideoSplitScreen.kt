package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.StorageUtils
import com.example.ui.components.EmptyMediaSelector
import com.example.ui.components.GlassCard
import com.example.ui.components.MediaFileCard
import com.example.ui.components.ProcessingModal
import com.example.ui.components.ResultBottomSheet
import com.example.ui.theme.*
import com.example.viewmodel.MediaSlimViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoSplitScreen(
    viewModel: MediaSlimViewModel,
    onNavigateBack: () -> Unit
) {
    BackHandler { onNavigateBack() }

    val selectedMedia by viewModel.selectedMedia.collectAsState()
    val progress by viewModel.progress.collectAsState()
    val batchResults by viewModel.batchResults.collectAsState()
    val activeResult by viewModel.activeResult.collectAsState()

    var selectedIntervalSec by remember { mutableIntStateOf(30) }

    val totalDurationMs = selectedMedia?.durationMs ?: 0L
    val calculatedParts = if (totalDurationMs > 0 && selectedIntervalSec > 0) {
        Math.ceil(totalDurationMs.toDouble() / (selectedIntervalSec * 1000.0)).toInt().coerceAtLeast(1)
    } else 1

    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { viewModel.onMediaSelected(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Video Splitter", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBg)
            )
        },
        containerColor = DarkBg
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (selectedMedia == null) {
                item {
                    EmptyMediaSelector(
                        title = "Select Video to Split",
                        subtitle = "Instant lossless stream-copy chunking for WhatsApp, Instagram, and TikTok.",
                        buttonText = "Choose Video",
                        icon = Icons.Default.CallSplit,
                        onSelect = {
                            pickVideoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                    )
                }
            } else {
                item {
                    MediaFileCard(
                        mediaInfo = selectedMedia!!,
                        onChangeFile = {
                            pickVideoLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                            )
                        }
                    )
                }

                item {
                    GlassCard(borderColor = DarkBorderGlass) {
                        Column(modifier = Modifier.padding(18.dp)) {
                            Text(
                                text = "Social Media Split Presets",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Zero re-encoding delay. Cuts cleanly in milliseconds.",
                                style = MaterialTheme.typography.bodySmall,
                                color = DarkTextSecondary
                            )
                            Spacer(modifier = Modifier.height(14.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    Pair(15, "15s (Reel)"),
                                    Pair(30, "30s (WhatsApp)"),
                                    Pair(60, "60s (Story)")
                                ).forEach { (sec, label) ->
                                    val isSelected = selectedIntervalSec == sec
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(if (isSelected) NeonCyan else DarkSurface3)
                                            .border(1.dp, if (isSelected) NeonCyan else DarkBorderGlass, RoundedCornerShape(10.dp))
                                            .clickable { selectedIntervalSec = sec }
                                            .padding(vertical = 10.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = label,
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                            color = if (isSelected) Color.Black else DarkTextPrimary
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Custom Interval",
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(
                                    text = "${selectedIntervalSec}s",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.ExtraBold),
                                    color = NeonCyan
                                )
                            }
                            Slider(
                                value = selectedIntervalSec.toFloat(),
                                onValueChange = { selectedIntervalSec = it.toInt() },
                                valueRange = 10f..120f,
                                steps = 21,
                                modifier = Modifier.testTag("split_interval_slider")
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DarkSurface3)
                                    .border(1.dp, DarkBorderGlass, RoundedCornerShape(10.dp))
                                    .padding(12.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Info,
                                        contentDescription = null,
                                        tint = NeonCyan,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Will export $calculatedParts parts (max ${selectedIntervalSec}s per clip)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = DarkTextPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Button(
                        onClick = {
                            viewModel.splitVideo(chunkDurationMs = selectedIntervalSec * 1000L)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("split_video_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(imageVector = Icons.Default.CallSplit, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Split Video into $calculatedParts Parts",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }

                if (batchResults.isNotEmpty()) {
                    item {
                        Text(
                            text = "Generated Split Parts (${batchResults.size})",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }

                    itemsIndexed(batchResults) { index, part ->
                        GlassCard(borderColor = DarkBorderGlass) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(DarkSurface3, RoundedCornerShape(8.dp))
                                        .border(1.dp, NeonCyan.copy(alpha = 0.5f), RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "${index + 1}",
                                        fontWeight = FontWeight.Bold,
                                        color = NeonCyan
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = part.outputFileName,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        text = "${StorageUtils.formatDuration(part.durationMs)} • ${StorageUtils.formatFileSize(part.outputSizeBytes)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = DarkTextSecondary
                                    )
                                }
                                IconButton(onClick = { viewModel.shareResult(part) }) {
                                    Icon(Icons.Default.Share, contentDescription = "Share", tint = NeonCyan)
                                }
                                IconButton(onClick = { viewModel.saveResultToGallery(part) }) {
                                    Icon(Icons.Default.SaveAlt, contentDescription = "Save", tint = MintEmerald)
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(28.dp))
                }
            }
        }
    }

    ProcessingModal(progress = progress)

    ResultBottomSheet(
        result = activeResult,
        onDismiss = { viewModel.dismissResult() },
        onSaveToGallery = { viewModel.saveResultToGallery(it) },
        onShare = { viewModel.shareResult(it) },
        onOpen = { viewModel.openResult(it) }
    )
}
