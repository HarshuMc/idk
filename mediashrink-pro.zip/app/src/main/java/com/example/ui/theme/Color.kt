package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Futuristic Electric Cyan & Neon Emerald
val ElectricCyan = Color(0xFF00F2FE)
val ElectricCyanGlow = Color(0x3300F2FE)

val NeonEmerald = Color(0xFF10B981)
val NeonEmeraldGlow = Color(0x3310B981)

// Deep Violet / Indigo Gradients for AI & Pro Modules
val IndigoViolet = Color(0xFF6366F1)
val ElectricViolet = Color(0xFF8B5CF6)
val DeepIndigo = Color(0xFF4F46E5)
val VioletGlow = Color(0x338B5CF6)

// Supporting Accent Tones
val SunsetAmber = Color(0xFFF59E0B)
val RoseCoral = Color(0xFFF43F5E)

// Backwards-compatible aliases
val NeonCyan = ElectricCyan
val CyanGlow = ElectricCyanGlow
val MintEmerald = NeonEmerald
val MintEmeraldGlow = NeonEmeraldGlow

// Deep OLED Black & Luxury Frosted Glass Palette
val OledBlack = Color(0xFF060608)
val DarkBg = OledBlack
val DarkSurface1 = Color(0xFF0D0F17)
val DarkSurface2 = Color(0xFF131722)
val DarkSurface3 = Color(0xFF1C2234)
val DarkGlassFill = Color(0x990D0F17)
val DarkBorderGlass = Color(0xFF1E2438)
val DarkBorderGlassActive = Color(0x8000F2FE)
val DarkTextPrimary = Color(0xFFF8FAFC)
val DarkTextSecondary = Color(0xFF94A3B8)
val DarkTextMuted = Color(0xFF64748B)

// Clean Crisp Light Palette
val LightBg = Color(0xFFF8FAFC)
val LightSurface1 = Color(0xFFFFFFFF)
val LightSurface2 = Color(0xFFF1F5F9)
val LightSurface3 = Color(0xFFE2E8F0)
val LightBorderGlass = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)
val LightTextMuted = Color(0xFF94A3B8)

