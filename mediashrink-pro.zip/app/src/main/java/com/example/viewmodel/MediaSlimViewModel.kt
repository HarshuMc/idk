package com.example.viewmodel

import android.app.Application
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.*
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream

class MediaSlimViewModel(application: Application) : AndroidViewModel(application) {

    // General media selection
    private val _selectedMedia = MutableStateFlow<SourceMediaInfo?>(null)
    val selectedMedia: StateFlow<SourceMediaInfo?> = _selectedMedia.asStateFlow()

    // Multi-selection queues for Bulk Compressors
    private val _selectedBatchImages = MutableStateFlow<List<Uri>>(emptyList())
    val selectedBatchImages: StateFlow<List<Uri>> = _selectedBatchImages.asStateFlow()

    private val _selectedBatchVideos = MutableStateFlow<List<Uri>>(emptyList())
    val selectedBatchVideos: StateFlow<List<Uri>> = _selectedBatchVideos.asStateFlow()

    private val _selectedBatchAudios = MutableStateFlow<List<Uri>>(emptyList())
    val selectedBatchAudios: StateFlow<List<Uri>> = _selectedBatchAudios.asStateFlow()

    // =========================================================================
    // 100% ISOLATED SESSION FOR BACKGROUND REMOVER
    // =========================================================================
    private val _bgRemoverMedia = MutableStateFlow<SourceMediaInfo?>(null)
    val bgRemoverMedia: StateFlow<SourceMediaInfo?> = _bgRemoverMedia.asStateFlow()

    private val _bgRemoverWorkingBmp = MutableStateFlow<Bitmap?>(null)
    val bgRemoverWorkingBmp: StateFlow<Bitmap?> = _bgRemoverWorkingBmp.asStateFlow()

    private val _bgRemoverOriginalBmp = MutableStateFlow<Bitmap?>(null)
    val bgRemoverOriginalBmp: StateFlow<Bitmap?> = _bgRemoverOriginalBmp.asStateFlow()

    private val bgUndoStack = mutableListOf<Bitmap>()
    private val bgRedoStack = mutableListOf<Bitmap>()

    private val _bgCanUndo = MutableStateFlow(false)
    val bgCanUndo: StateFlow<Boolean> = _bgCanUndo.asStateFlow()

    private val _bgCanRedo = MutableStateFlow(false)
    val bgCanRedo: StateFlow<Boolean> = _bgCanRedo.asStateFlow()

    fun onBgRemoverMediaSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val info = StorageUtils.getMediaInfo(context, uri)
            _bgRemoverMedia.value = info

            try {
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
                if (bmp != null) {
                    _bgRemoverOriginalBmp.value = bmp
                    _bgRemoverWorkingBmp.value = bmp.copy(Bitmap.Config.ARGB_8888, true)
                    bgUndoStack.clear()
                    bgRedoStack.clear()
                    pushBgUndo(_bgRemoverWorkingBmp.value!!)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun pushBgUndo(bitmap: Bitmap) {
        bgUndoStack.add(bitmap.copy(Bitmap.Config.ARGB_8888, true))
        if (bgUndoStack.size > 12) bgUndoStack.removeAt(0)
        bgRedoStack.clear()
        _bgCanUndo.value = bgUndoStack.size > 1
        _bgCanRedo.value = false
    }

    fun undoBg() {
        if (bgUndoStack.size > 1) {
            val current = bgUndoStack.removeAt(bgUndoStack.size - 1)
            bgRedoStack.add(current)
            val prev = bgUndoStack.last()
            _bgRemoverWorkingBmp.value = prev.copy(Bitmap.Config.ARGB_8888, true)
            _bgCanUndo.value = bgUndoStack.size > 1
            _bgCanRedo.value = true
        }
    }

    fun redoBg() {
        if (bgRedoStack.isNotEmpty()) {
            val next = bgRedoStack.removeAt(bgRedoStack.size - 1)
            bgUndoStack.add(next)
            _bgRemoverWorkingBmp.value = next.copy(Bitmap.Config.ARGB_8888, true)
            _bgCanUndo.value = true
            _bgCanRedo.value = bgRedoStack.isNotEmpty()
        }
    }

    fun clearBgRemover() {
        _bgRemoverMedia.value = null
        _bgRemoverWorkingBmp.value = null
        _bgRemoverOriginalBmp.value = null
        bgUndoStack.clear()
        bgRedoStack.clear()
        _bgCanUndo.value = false
        _bgCanRedo.value = false
    }

    // =========================================================================
    // 100% ISOLATED SESSION FOR OBJECT ERASER
    // =========================================================================
    private val _objectEraserMedia = MutableStateFlow<SourceMediaInfo?>(null)
    val objectEraserMedia: StateFlow<SourceMediaInfo?> = _objectEraserMedia.asStateFlow()

    private val _objectEraserWorkingBmp = MutableStateFlow<Bitmap?>(null)
    val objectEraserWorkingBmp: StateFlow<Bitmap?> = _objectEraserWorkingBmp.asStateFlow()

    private val _objectEraserOriginalBmp = MutableStateFlow<Bitmap?>(null)
    val objectEraserOriginalBmp: StateFlow<Bitmap?> = _objectEraserOriginalBmp.asStateFlow()

    private val eraserUndoStack = mutableListOf<Bitmap>()
    private val eraserRedoStack = mutableListOf<Bitmap>()

    private val _eraserCanUndo = MutableStateFlow(false)
    val eraserCanUndo: StateFlow<Boolean> = _eraserCanUndo.asStateFlow()

    private val _eraserCanRedo = MutableStateFlow(false)
    val eraserCanRedo: StateFlow<Boolean> = _eraserCanRedo.asStateFlow()

    fun onObjectEraserMediaSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val info = StorageUtils.getMediaInfo(context, uri)
            _objectEraserMedia.value = info

            try {
                val bmp = context.contentResolver.openInputStream(uri)?.use {
                    BitmapFactory.decodeStream(it)
                }
                if (bmp != null) {
                    _objectEraserOriginalBmp.value = bmp
                    _objectEraserWorkingBmp.value = bmp.copy(Bitmap.Config.ARGB_8888, true)
                    eraserUndoStack.clear()
                    eraserRedoStack.clear()
                    pushEraserUndo(_objectEraserWorkingBmp.value!!)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun pushEraserUndo(bitmap: Bitmap) {
        eraserUndoStack.add(bitmap.copy(Bitmap.Config.ARGB_8888, true))
        if (eraserUndoStack.size > 12) eraserUndoStack.removeAt(0)
        eraserRedoStack.clear()
        _eraserCanUndo.value = eraserUndoStack.size > 1
        _eraserCanRedo.value = false
    }

    fun undoEraser() {
        if (eraserUndoStack.size > 1) {
            val current = eraserUndoStack.removeAt(eraserUndoStack.size - 1)
            eraserRedoStack.add(current)
            val prev = eraserUndoStack.last()
            _objectEraserWorkingBmp.value = prev.copy(Bitmap.Config.ARGB_8888, true)
            _eraserCanUndo.value = eraserUndoStack.size > 1
            _eraserCanRedo.value = true
        }
    }

    fun redoEraser() {
        if (eraserRedoStack.isNotEmpty()) {
            val next = eraserRedoStack.removeAt(eraserRedoStack.size - 1)
            eraserUndoStack.add(next)
            _objectEraserWorkingBmp.value = next.copy(Bitmap.Config.ARGB_8888, true)
            _eraserCanUndo.value = true
            _eraserCanRedo.value = eraserRedoStack.isNotEmpty()
        }
    }

    fun clearObjectEraser() {
        _objectEraserMedia.value = null
        _objectEraserWorkingBmp.value = null
        _objectEraserOriginalBmp.value = null
        eraserUndoStack.clear()
        eraserRedoStack.clear()
        _eraserCanUndo.value = false
        _eraserCanRedo.value = false
    }

    // Processing progress & results
    private val _progress = MutableStateFlow(ProcessingProgress())
    val progress: StateFlow<ProcessingProgress> = _progress.asStateFlow()

    private val _activeResult = MutableStateFlow<ProcessedResult?>(null)
    val activeResult: StateFlow<ProcessedResult?> = _activeResult.asStateFlow()

    private val _batchResults = MutableStateFlow<List<ProcessedResult>>(emptyList())
    val batchResults: StateFlow<List<ProcessedResult>> = _batchResults.asStateFlow()

    private val _history = MutableStateFlow<List<ProcessedResult>>(emptyList())
    val history: StateFlow<List<ProcessedResult>> = _history.asStateFlow()

    fun onMediaSelected(uri: Uri) {
        viewModelScope.launch {
            val context = getApplication<Application>()
            val info = StorageUtils.getMediaInfo(context, uri)
            _selectedMedia.value = info
        }
    }

    fun onBatchImagesSelected(uris: List<Uri>) {
        _selectedBatchImages.value = uris
        if (uris.isNotEmpty()) onMediaSelected(uris.first())
    }

    fun onBatchVideosSelected(uris: List<Uri>) {
        _selectedBatchVideos.value = uris
        if (uris.isNotEmpty()) onMediaSelected(uris.first())
    }

    fun onBatchAudiosSelected(uris: List<Uri>) {
        _selectedBatchAudios.value = uris
        if (uris.isNotEmpty()) onMediaSelected(uris.first())
    }

    fun clearSelection() {
        _selectedMedia.value = null
        _selectedBatchImages.value = emptyList()
        _selectedBatchVideos.value = emptyList()
        _selectedBatchAudios.value = emptyList()
        _batchResults.value = emptyList()
    }

    fun dismissResult() {
        _activeResult.value = null
        _batchResults.value = emptyList()
    }

    // --- Background Remover Actions ---
    fun applyBgAuto() {
        val current = _bgRemoverWorkingBmp.value ?: return
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Auto AI subject isolation...")
            try {
                val isolated = BgRemoverEngine.removeBgAuto(current) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _bgRemoverWorkingBmp.value = isolated
                pushBgUndo(isolated)
                _progress.value = ProcessingProgress(isProcessing = false)
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun applyBgChroma(targetColor: Int, tolerance: Float = 0.35f, feather: Float = 0.15f) {
        val current = _bgRemoverWorkingBmp.value ?: return
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Applying chroma key...")
            try {
                val result = BgRemoverEngine.removeBgChroma(current, targetColor, tolerance, feather)
                _bgRemoverWorkingBmp.value = result
                pushBgUndo(result)
                _progress.value = ProcessingProgress(isProcessing = false)
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun applyMagicWand(touchX: Int, touchY: Int, tolerance: Float = 0.25f) {
        val current = _bgRemoverWorkingBmp.value ?: return
        viewModelScope.launch {
            try {
                val result = BgRemoverEngine.removeBgMagicWand(current, touchX, touchY, tolerance)
                _bgRemoverWorkingBmp.value = result
                pushBgUndo(result)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun applyBgBrush(centerX: Float, centerY: Float, radius: Float, isRepair: Boolean) {
        val current = _bgRemoverWorkingBmp.value ?: return
        val orig = _bgRemoverOriginalBmp.value ?: return
        val result = BgRemoverEngine.applyBrushStroke(current, orig, centerX, centerY, radius, isRepair)
        _bgRemoverWorkingBmp.value = result
    }

    fun commitBgBrush() {
        _bgRemoverWorkingBmp.value?.let { pushBgUndo(it) }
    }

    fun saveBgRemovedBitmap(backdropColor: Int?, isBlurPortrait: Boolean) {
        val current = _bgRemoverWorkingBmp.value ?: return
        val orig = _bgRemoverOriginalBmp.value ?: return
        val context = getApplication<Application>()

        viewModelScope.launch {
            val composite = BgRemoverEngine.createCompositeWithBackdrop(current, orig, backdropColor, isBlurPortrait)
            val outputFile = StorageUtils.getOutputCacheFile(context, "bg_removed", "png")
            FileOutputStream(outputFile).use { out ->
                composite.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val res = ProcessedResult(
                toolType = ToolType.BG_REMOVER,
                originalFileName = _bgRemoverMedia.value?.fileName ?: "photo.jpg",
                outputFileName = "cutout_${System.currentTimeMillis()}.png",
                originalSizeBytes = _bgRemoverMedia.value?.fileSizeBytes ?: 0L,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "image/png"
            )
            _history.update { listOf(res) + it }
            _activeResult.value = res
        }
    }

    // --- Object Eraser Actions ---
    fun eraseObject(maskBitmap: Bitmap) {
        val source = _objectEraserWorkingBmp.value ?: return
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Content-Aware AI Inpainting...")
            try {
                val inpainted = ObjectEraserEngine.eraseObject(source, maskBitmap) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _objectEraserWorkingBmp.value = inpainted
                pushEraserUndo(inpainted)
                _progress.value = ProcessingProgress(isProcessing = false)
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun saveObjectErasedBitmap() {
        val current = _objectEraserWorkingBmp.value ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            val outputFile = StorageUtils.getOutputCacheFile(context, "object_erased", "png")
            FileOutputStream(outputFile).use { out ->
                current.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val res = ProcessedResult(
                toolType = ToolType.OBJECT_ERASER,
                originalFileName = _objectEraserMedia.value?.fileName ?: "photo.jpg",
                outputFileName = "cleaned_${System.currentTimeMillis()}.png",
                originalSizeBytes = _objectEraserMedia.value?.fileSizeBytes ?: 0L,
                outputSizeBytes = outputFile.length(),
                outputUri = Uri.fromFile(outputFile),
                outputMimeType = "image/png"
            )
            _history.update { listOf(res) + it }
            _activeResult.value = res
        }
    }

    // --- Image Compression ---
    fun compressImages(quality: Int, resolutionScale: Float, format: ImageOutputFormat) {
        val uris = if (_selectedBatchImages.value.isNotEmpty()) _selectedBatchImages.value else _selectedMedia.value?.uri?.let { listOf(it) } ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Compressing images...", totalItems = uris.size)
            val results = mutableListOf<ProcessedResult>()
            try {
                for ((index, uri) in uris.withIndex()) {
                    _progress.update { it.copy(currentStage = "Compressing ${index + 1} of ${uris.size}...", itemsCompleted = index) }
                    val res = ImageProcessor.compressImage(context, uri, quality, resolutionScale, format) { p ->
                        _progress.update { it.copy(progressPercent = (index.toFloat() + p) / uris.size.toFloat()) }
                    }
                    results.add(res)
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- Video Compression ---
    val isMuteAudioEnabled = MutableStateFlow(false)

    fun setMuteAudio(enabled: Boolean) {
        isMuteAudioEnabled.value = enabled
    }

    fun compressVideos(
        preset: VideoCompressionPreset,
        customBitrateKbps: Int = 1200,
        customScale: Float = 0.7f,
        muteAudio: Boolean = isMuteAudioEnabled.value
    ) {
        val uris = if (_selectedBatchVideos.value.isNotEmpty()) _selectedBatchVideos.value else _selectedMedia.value?.uri?.let { listOf(it) } ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = if (muteAudio) "Transcoding video (Muted)..." else "Hardware video transcoding...", totalItems = uris.size)
            val results = mutableListOf<ProcessedResult>()
            try {
                for ((index, uri) in uris.withIndex()) {
                    _progress.update { it.copy(currentStage = "Transcoding video ${index + 1} of ${uris.size}...", itemsCompleted = index) }
                    val res = VideoCompressorEngine.compressVideo(context, uri, preset, customBitrateKbps, customScale, muteAudio) { p ->
                        _progress.update { it.copy(progressPercent = (index.toFloat() + p) / uris.size.toFloat()) }
                    }
                    results.add(res)
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- PDF Master & Merger State & Actions ---
    private val _pdfPages = MutableStateFlow<List<PdfPageModel>>(emptyList())
    val pdfPages: StateFlow<List<PdfPageModel>> = _pdfPages.asStateFlow()

    fun loadPdf(uri: Uri) {
        onMediaSelected(uri)
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Rendering PDF pages...")
            try {
                val pages = PdfEngine.loadPdfPages(context, uri)
                _pdfPages.value = pages
                _progress.value = ProcessingProgress(isProcessing = false)
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun movePdfPage(fromIndex: Int, toIndex: Int) {
        val current = _pdfPages.value.toMutableList()
        if (fromIndex in current.indices && toIndex in current.indices) {
            val item = current.removeAt(fromIndex)
            current.add(toIndex, item)
            _pdfPages.value = current
        }
    }

    fun rotatePdfPage(index: Int) {
        val current = _pdfPages.value.toMutableList()
        if (index in current.indices) {
            val p = current[index]
            current[index] = p.copy(rotationDegrees = (p.rotationDegrees + 90) % 360)
            _pdfPages.value = current
        }
    }

    fun deletePdfPage(index: Int) {
        val current = _pdfPages.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _pdfPages.value = current
        }
    }

    fun exportPdf(qualityPercent: Int = 85) {
        val uri = _selectedMedia.value?.uri ?: return
        val pages = _pdfPages.value
        if (pages.isEmpty()) return
        val context = getApplication<Application>()

        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Generating optimized PDF...")
            try {
                val outputFile = PdfEngine.exportPdf(context, uri, pages, qualityPercent) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                val res = ProcessedResult(
                    toolType = ToolType.PDF_MASTER,
                    originalFileName = _selectedMedia.value?.fileName ?: "document.pdf",
                    outputFileName = "master_${System.currentTimeMillis()}.pdf",
                    originalSizeBytes = _selectedMedia.value?.fileSizeBytes ?: 0L,
                    outputSizeBytes = outputFile.length(),
                    outputUri = Uri.fromFile(outputFile),
                    outputMimeType = "application/pdf"
                )
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun mergePdfs(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Merging ${uris.size} PDF documents...")
            try {
                val outputFile = PdfEngine.mergePdfs(context, uris) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                val totalOriginalBytes = uris.sumOf { StorageUtils.getMediaInfo(context, it).fileSizeBytes }
                val res = ProcessedResult(
                    toolType = ToolType.PDF_MASTER,
                    originalFileName = "${uris.size} Documents Merged",
                    outputFileName = "merged_${System.currentTimeMillis()}.pdf",
                    originalSizeBytes = totalOriginalBytes,
                    outputSizeBytes = outputFile.length(),
                    outputUri = Uri.fromFile(outputFile),
                    outputMimeType = "application/pdf"
                )
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- Audio Denoiser & Vocal Enhancer Actions ---
    fun denoiseAudio(
        hissReductionPercent: Int = 75,
        vocalBoostDb: Float = 3.5f,
        noiseGateFloor: Float = 0.04f
    ) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()

        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Applying Neural Audio Clean-up & Vocal Boost...")
            try {
                val outputFile = AudioDenoiserEngine.denoiseAudio(
                    context, uri, hissReductionPercent, vocalBoostDb, noiseGateFloor
                ) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                val res = ProcessedResult(
                    toolType = ToolType.AUDIO_DENOISER,
                    originalFileName = _selectedMedia.value?.fileName ?: "audio.mp3",
                    outputFileName = "denoised_${System.currentTimeMillis()}.m4a",
                    originalSizeBytes = _selectedMedia.value?.fileSizeBytes ?: 0L,
                    outputSizeBytes = outputFile.length(),
                    outputUri = Uri.fromFile(outputFile),
                    outputMimeType = "audio/mp4"
                )
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- Sidecar Subtitle Injector Actions ---
    private val _subtitleCues = MutableStateFlow<List<SubtitleCue>>(emptyList())
    val subtitleCues: StateFlow<List<SubtitleCue>> = _subtitleCues.asStateFlow()

    fun loadVideoForSubtitles(uri: Uri) {
        onMediaSelected(uri)
        val durationMs = _selectedMedia.value?.durationMs ?: 15000L
        _subtitleCues.value = SubtitleEngine.createDefaultCues(durationMs)
    }

    fun addSubtitleCue(text: String, startMs: Long, endMs: Long) {
        val current = _subtitleCues.value.toMutableList()
        val nextId = (current.maxOfOrNull { it.id } ?: 0) + 1
        current.add(SubtitleCue(nextId, startMs, endMs, text))
        current.sortBy { it.startTimeMs }
        _subtitleCues.value = current
    }

    fun updateSubtitleCue(index: Int, text: String, startMs: Long, endMs: Long) {
        val current = _subtitleCues.value.toMutableList()
        if (index in current.indices) {
            current[index] = current[index].copy(text = text, startTimeMs = startMs, endTimeMs = endMs)
            current.sortBy { it.startTimeMs }
            _subtitleCues.value = current
        }
    }

    fun deleteSubtitleCue(index: Int) {
        val current = _subtitleCues.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _subtitleCues.value = current
        }
    }

    fun exportSidecarSubtitle(offsetMs: Long = 0L) {
        val media = _selectedMedia.value ?: return
        val cues = _subtitleCues.value
        val context = getApplication<Application>()

        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Exporting Synced Sidecar Subtitles (.srt)...")
            try {
                val outputFile = SubtitleEngine.exportSidecarSrt(context, media.fileName, cues, offsetMs)
                val res = ProcessedResult(
                    toolType = ToolType.SUBTITLE_INJECTOR,
                    originalFileName = media.fileName,
                    outputFileName = outputFile.name,
                    originalSizeBytes = media.fileSizeBytes,
                    outputSizeBytes = outputFile.length(),
                    outputUri = Uri.fromFile(outputFile),
                    outputMimeType = "text/plain"
                )
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- Audio Compression ---
    fun compressAudios(targetBitrateKbps: Int, targetSampleRate: Int) {
        val uris = if (_selectedBatchAudios.value.isNotEmpty()) _selectedBatchAudios.value else _selectedMedia.value?.uri?.let { listOf(it) } ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Compressing audio queue...", totalItems = uris.size)
            val results = mutableListOf<ProcessedResult>()
            try {
                for ((index, uri) in uris.withIndex()) {
                    _progress.update { it.copy(currentStage = "Compressing audio ${index + 1} of ${uris.size}...", itemsCompleted = index) }
                    val res = AudioCompressorEngine.compressAudio(context, uri, targetBitrateKbps, targetSampleRate) { p ->
                        _progress.update { it.copy(progressPercent = (index.toFloat() + p) / uris.size.toFloat()) }
                    }
                    results.add(res)
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // --- Other Tools ---
    fun compressGif(frameSkipStep: Int, scaleFactor: Float, maxColors: Int) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Optimizing GIF frames & palette...")
            try {
                val res = GifProcessor.compressGif(context, uri, frameSkipStep, scaleFactor, maxColors) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun convertVideoToGif(startMs: Long, endMs: Long, targetFps: Int, targetWidth: Int, maxColors: Int) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Converting video to GIF...")
            try {
                val res = VideoToGifConverter.convertVideoToGif(context, uri, startMs, endMs, targetFps, targetWidth, maxColors) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun convertAudioFormat(targetFormat: AudioTargetFormat, targetBitrateKbps: Int = 192) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Converting audio format...")
            try {
                val res = AudioFormatConverter.convertAudioFormat(context, uri, targetFormat, targetBitrateKbps) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun convertVideoCodec(targetContainer: VideoTargetContainer) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Repackaging container...")
            try {
                val res = VideoCodecChanger.convertVideoCodecAndContainer(context, uri, targetContainer) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun extractIconsAuto(minDimensionPx: Int = 24) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Auto-detecting icon symbols...")
            try {
                val results = IconExtractorEngine.extractIconsAuto(context, uri, minDimensionPx) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun extractIconsGrid(rows: Int, cols: Int) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Slicing ${rows}x${cols} icon grid...")
            try {
                val results = IconExtractorEngine.extractIconsGrid(context, uri, rows, cols) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun extractAudio() {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Extracting lossless audio...")
            try {
                val res = AudioExtractorEngine.extractAudio(context, uri) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun trimVideo(startMs: Long, endMs: Long) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Lossless trimming...")
            try {
                val res = VideoTrimmerAndSplitter.trimVideo(context, uri, startMs, endMs) { p ->
                    _progress.update { it.copy(progressPercent = p) }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { listOf(res) + it }
                _activeResult.value = res
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    fun splitVideo(chunkDurationMs: Long) {
        val uri = _selectedMedia.value?.uri ?: return
        val context = getApplication<Application>()
        viewModelScope.launch {
            _progress.value = ProcessingProgress(isProcessing = true, currentStage = "Splitting video into chunks...")
            try {
                val results = VideoTrimmerAndSplitter.splitVideo(context, uri, chunkDurationMs) { p, current, total ->
                    _progress.update {
                        it.copy(progressPercent = p, currentStage = "Splitting part $current of $total...", itemsCompleted = current, totalItems = total)
                    }
                }
                _progress.value = ProcessingProgress(isProcessing = false)
                _history.update { results + it }
                _batchResults.value = results
                _activeResult.value = results.firstOrNull()
            } catch (e: Exception) {
                _progress.value = ProcessingProgress(isProcessing = false, error = e.localizedMessage)
            }
        }
    }

    // Save / Share / Open Helpers
    fun saveResultToGallery(result: ProcessedResult) {
        val context = getApplication<Application>()
        val file = File(result.outputUri.path ?: "")
        if (!file.exists()) {
            Toast.makeText(context, "Output file not found", Toast.LENGTH_SHORT).show()
            return
        }

        val isImage = result.outputMimeType.startsWith("image/")
        val isVideo = result.outputMimeType.startsWith("video/")
        val isAudio = result.outputMimeType.startsWith("audio/")

        val savedUri = StorageUtils.saveToMediaStore(
            context, file, result.outputFileName, result.outputMimeType, isImage, isVideo, isAudio
        )
        if (savedUri != null) {
            Toast.makeText(context, "Saved to MediaStore / Gallery!", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Saved to App Storage", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareResult(result: ProcessedResult) {
        val context = getApplication<Application>()
        val file = File(result.outputUri.path ?: "")
        if (file.exists()) {
            StorageUtils.shareMedia(context, file, result.outputMimeType, "Share ${result.outputFileName}")
        }
    }

    fun openResult(result: ProcessedResult) {
        val context = getApplication<Application>()
        val file = File(result.outputUri.path ?: "")
        if (file.exists()) {
            StorageUtils.openMedia(context, file, result.outputMimeType)
        }
    }

    fun deleteHistoryItem(result: ProcessedResult) {
        _history.update { list -> list.filter { it.id != result.id } }
        try {
            val file = File(result.outputUri.path ?: "")
            if (file.exists()) file.delete()
        } catch (e: Exception) {
            // Ignore
        }
    }
}
