package com.example

import com.example.engine.StorageUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleRobolectricTest {
    @Test
    fun testAppFormattingUtils() {
        assertEquals("0 B", StorageUtils.formatFileSize(0))
        assertEquals("10 MB", StorageUtils.formatFileSize(10 * 1024 * 1024))
    }
}
