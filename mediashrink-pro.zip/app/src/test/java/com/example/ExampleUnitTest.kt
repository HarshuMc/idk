package com.example

import com.example.engine.StorageUtils
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testFormatFileSize() {
        assertEquals("0 B", StorageUtils.formatFileSize(0))
        assertEquals("1 KB", StorageUtils.formatFileSize(1024))
        assertEquals("1 MB", StorageUtils.formatFileSize(1024 * 1024))
    }

    @Test
    fun testFormatDuration() {
        assertEquals("00:00", StorageUtils.formatDuration(0))
        assertEquals("00:30", StorageUtils.formatDuration(30000))
        assertEquals("01:15", StorageUtils.formatDuration(75000))
    }
}
